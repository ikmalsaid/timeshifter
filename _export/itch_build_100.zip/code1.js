gdjs.creditsCode = {};
gdjs.creditsCode.GDtransitionObjects1= [];
gdjs.creditsCode.GDtransitionObjects2= [];
gdjs.creditsCode.GDtransitionObjects3= [];
gdjs.creditsCode.GDblackscreenObjects1= [];
gdjs.creditsCode.GDblackscreenObjects2= [];
gdjs.creditsCode.GDblackscreenObjects3= [];
gdjs.creditsCode.GDtitle_95bgObjects1= [];
gdjs.creditsCode.GDtitle_95bgObjects2= [];
gdjs.creditsCode.GDtitle_95bgObjects3= [];
gdjs.creditsCode.GDtitle_95fgObjects1= [];
gdjs.creditsCode.GDtitle_95fgObjects2= [];
gdjs.creditsCode.GDtitle_95fgObjects3= [];
gdjs.creditsCode.GDred_95buttonObjects1= [];
gdjs.creditsCode.GDred_95buttonObjects2= [];
gdjs.creditsCode.GDred_95buttonObjects3= [];
gdjs.creditsCode.GDgreen_95buttonObjects1= [];
gdjs.creditsCode.GDgreen_95buttonObjects2= [];
gdjs.creditsCode.GDgreen_95buttonObjects3= [];
gdjs.creditsCode.GDmoving_95bgObjects1= [];
gdjs.creditsCode.GDmoving_95bgObjects2= [];
gdjs.creditsCode.GDmoving_95bgObjects3= [];
gdjs.creditsCode.GDcredits_95textObjects1= [];
gdjs.creditsCode.GDcredits_95textObjects2= [];
gdjs.creditsCode.GDcredits_95textObjects3= [];
gdjs.creditsCode.GDcredits_95text2Objects1= [];
gdjs.creditsCode.GDcredits_95text2Objects2= [];
gdjs.creditsCode.GDcredits_95text2Objects3= [];
gdjs.creditsCode.GDtitle_95bgObjects1= [];
gdjs.creditsCode.GDtitle_95bgObjects2= [];
gdjs.creditsCode.GDtitle_95bgObjects3= [];
gdjs.creditsCode.GDtitle_95fgObjects1= [];
gdjs.creditsCode.GDtitle_95fgObjects2= [];
gdjs.creditsCode.GDtitle_95fgObjects3= [];
gdjs.creditsCode.GDbackObjects1= [];
gdjs.creditsCode.GDbackObjects2= [];
gdjs.creditsCode.GDbackObjects3= [];


gdjs.creditsCode.asyncCallback11063372 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.creditsCode.GDbackObjects3);
{for(var i = 0, len = gdjs.creditsCode.GDbackObjects3.length ;i < len;++i) {
    gdjs.creditsCode.GDbackObjects3[i].getBehavior("Tween").addObjectPositionYTween("slide_in", 700, "linear", 500, false);
}
}}
gdjs.creditsCode.eventsList0 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.6), (runtimeScene) => (gdjs.creditsCode.asyncCallback11063372(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.creditsCode.asyncCallback11062204 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("credits_text"), gdjs.creditsCode.GDcredits_95textObjects2);
gdjs.copyArray(runtimeScene.getObjects("credits_text2"), gdjs.creditsCode.GDcredits_95text2Objects2);
{for(var i = 0, len = gdjs.creditsCode.GDcredits_95textObjects2.length ;i < len;++i) {
    gdjs.creditsCode.GDcredits_95textObjects2[i].getBehavior("Tween").addObjectPositionXTween("slide_in", 173, "linear", 750, false);
}
}{for(var i = 0, len = gdjs.creditsCode.GDcredits_95text2Objects2.length ;i < len;++i) {
    gdjs.creditsCode.GDcredits_95text2Objects2[i].getBehavior("Tween").addObjectPositionXTween("slide_in", 173, "linear", 750, false);
}
}
{ //Subevents
gdjs.creditsCode.eventsList0(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.creditsCode.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.creditsCode.asyncCallback11062204(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.creditsCode.asyncCallback11066316 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "main", false);
}}
gdjs.creditsCode.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.creditsCode.asyncCallback11066316(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.creditsCode.eventsList3 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.creditsCode.GDtransitionObjects1);
{for(var i = 0, len = gdjs.creditsCode.GDtransitionObjects1.length ;i < len;++i) {
    gdjs.creditsCode.GDtransitionObjects1[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.5, "Vertical", "Backward", 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.creditsCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.creditsCode.GDbackObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.creditsCode.GDbackObjects1.length;i<l;++i) {
    if ( gdjs.creditsCode.GDbackObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.creditsCode.GDbackObjects1[k] = gdjs.creditsCode.GDbackObjects1[i];
        ++k;
    }
}
gdjs.creditsCode.GDbackObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11064500);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.creditsCode.GDtransitionObjects1);
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "sound\\button.mp3", 100, false, 100, 1);
}{for(var i = 0, len = gdjs.creditsCode.GDtransitionObjects1.length ;i < len;++i) {
    gdjs.creditsCode.GDtransitionObjects1[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.5, "Circular", "Forward", 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.creditsCode.eventsList2(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("moving_bg"), gdjs.creditsCode.GDmoving_95bgObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.creditsCode.GDmoving_95bgObjects1.length;i<l;++i) {
    if ( gdjs.creditsCode.GDmoving_95bgObjects1[i].getXOffset() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.creditsCode.GDmoving_95bgObjects1[k] = gdjs.creditsCode.GDmoving_95bgObjects1[i];
        ++k;
    }
}
gdjs.creditsCode.GDmoving_95bgObjects1.length = k;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(gdjs.randomInRange(-(2), 2));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("moving_bg"), gdjs.creditsCode.GDmoving_95bgObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.creditsCode.GDmoving_95bgObjects1.length;i<l;++i) {
    if ( gdjs.creditsCode.GDmoving_95bgObjects1[i].getYOffset() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.creditsCode.GDmoving_95bgObjects1[k] = gdjs.creditsCode.GDmoving_95bgObjects1[i];
        ++k;
    }
}
gdjs.creditsCode.GDmoving_95bgObjects1.length = k;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(gdjs.randomInRange(-(2), 2));
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("moving_bg"), gdjs.creditsCode.GDmoving_95bgObjects1);
{for(var i = 0, len = gdjs.creditsCode.GDmoving_95bgObjects1.length ;i < len;++i) {
    gdjs.creditsCode.GDmoving_95bgObjects1[i].setXOffset(gdjs.creditsCode.GDmoving_95bgObjects1[i].getXOffset() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))));
}
}{for(var i = 0, len = gdjs.creditsCode.GDmoving_95bgObjects1.length ;i < len;++i) {
    gdjs.creditsCode.GDmoving_95bgObjects1[i].setYOffset(gdjs.creditsCode.GDmoving_95bgObjects1[i].getYOffset() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};

gdjs.creditsCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.creditsCode.GDtransitionObjects1.length = 0;
gdjs.creditsCode.GDtransitionObjects2.length = 0;
gdjs.creditsCode.GDtransitionObjects3.length = 0;
gdjs.creditsCode.GDblackscreenObjects1.length = 0;
gdjs.creditsCode.GDblackscreenObjects2.length = 0;
gdjs.creditsCode.GDblackscreenObjects3.length = 0;
gdjs.creditsCode.GDtitle_95bgObjects1.length = 0;
gdjs.creditsCode.GDtitle_95bgObjects2.length = 0;
gdjs.creditsCode.GDtitle_95bgObjects3.length = 0;
gdjs.creditsCode.GDtitle_95fgObjects1.length = 0;
gdjs.creditsCode.GDtitle_95fgObjects2.length = 0;
gdjs.creditsCode.GDtitle_95fgObjects3.length = 0;
gdjs.creditsCode.GDred_95buttonObjects1.length = 0;
gdjs.creditsCode.GDred_95buttonObjects2.length = 0;
gdjs.creditsCode.GDred_95buttonObjects3.length = 0;
gdjs.creditsCode.GDgreen_95buttonObjects1.length = 0;
gdjs.creditsCode.GDgreen_95buttonObjects2.length = 0;
gdjs.creditsCode.GDgreen_95buttonObjects3.length = 0;
gdjs.creditsCode.GDmoving_95bgObjects1.length = 0;
gdjs.creditsCode.GDmoving_95bgObjects2.length = 0;
gdjs.creditsCode.GDmoving_95bgObjects3.length = 0;
gdjs.creditsCode.GDcredits_95textObjects1.length = 0;
gdjs.creditsCode.GDcredits_95textObjects2.length = 0;
gdjs.creditsCode.GDcredits_95textObjects3.length = 0;
gdjs.creditsCode.GDcredits_95text2Objects1.length = 0;
gdjs.creditsCode.GDcredits_95text2Objects2.length = 0;
gdjs.creditsCode.GDcredits_95text2Objects3.length = 0;
gdjs.creditsCode.GDtitle_95bgObjects1.length = 0;
gdjs.creditsCode.GDtitle_95bgObjects2.length = 0;
gdjs.creditsCode.GDtitle_95bgObjects3.length = 0;
gdjs.creditsCode.GDtitle_95fgObjects1.length = 0;
gdjs.creditsCode.GDtitle_95fgObjects2.length = 0;
gdjs.creditsCode.GDtitle_95fgObjects3.length = 0;
gdjs.creditsCode.GDbackObjects1.length = 0;
gdjs.creditsCode.GDbackObjects2.length = 0;
gdjs.creditsCode.GDbackObjects3.length = 0;

gdjs.creditsCode.eventsList3(runtimeScene);

return;

}

gdjs['creditsCode'] = gdjs.creditsCode;

gdjs.mainCode = {};
gdjs.mainCode.GDtransitionObjects1= [];
gdjs.mainCode.GDtransitionObjects2= [];
gdjs.mainCode.GDtransitionObjects3= [];
gdjs.mainCode.GDtransitionObjects4= [];
gdjs.mainCode.GDblackscreenObjects1= [];
gdjs.mainCode.GDblackscreenObjects2= [];
gdjs.mainCode.GDblackscreenObjects3= [];
gdjs.mainCode.GDblackscreenObjects4= [];
gdjs.mainCode.GDtitle_95bgObjects1= [];
gdjs.mainCode.GDtitle_95bgObjects2= [];
gdjs.mainCode.GDtitle_95bgObjects3= [];
gdjs.mainCode.GDtitle_95bgObjects4= [];
gdjs.mainCode.GDtitle_95fgObjects1= [];
gdjs.mainCode.GDtitle_95fgObjects2= [];
gdjs.mainCode.GDtitle_95fgObjects3= [];
gdjs.mainCode.GDtitle_95fgObjects4= [];
gdjs.mainCode.GDred_95buttonObjects1= [];
gdjs.mainCode.GDred_95buttonObjects2= [];
gdjs.mainCode.GDred_95buttonObjects3= [];
gdjs.mainCode.GDred_95buttonObjects4= [];
gdjs.mainCode.GDgreen_95buttonObjects1= [];
gdjs.mainCode.GDgreen_95buttonObjects2= [];
gdjs.mainCode.GDgreen_95buttonObjects3= [];
gdjs.mainCode.GDgreen_95buttonObjects4= [];
gdjs.mainCode.GDmoving_95bgObjects1= [];
gdjs.mainCode.GDmoving_95bgObjects2= [];
gdjs.mainCode.GDmoving_95bgObjects3= [];
gdjs.mainCode.GDmoving_95bgObjects4= [];
gdjs.mainCode.GDscroller_95bgObjects1= [];
gdjs.mainCode.GDscroller_95bgObjects2= [];
gdjs.mainCode.GDscroller_95bgObjects3= [];
gdjs.mainCode.GDscroller_95bgObjects4= [];
gdjs.mainCode.GDscroller_95textObjects1= [];
gdjs.mainCode.GDscroller_95textObjects2= [];
gdjs.mainCode.GDscroller_95textObjects3= [];
gdjs.mainCode.GDscroller_95textObjects4= [];
gdjs.mainCode.GDtitle1Objects1= [];
gdjs.mainCode.GDtitle1Objects2= [];
gdjs.mainCode.GDtitle1Objects3= [];
gdjs.mainCode.GDtitle1Objects4= [];
gdjs.mainCode.GDtitle2Objects1= [];
gdjs.mainCode.GDtitle2Objects2= [];
gdjs.mainCode.GDtitle2Objects3= [];
gdjs.mainCode.GDtitle2Objects4= [];
gdjs.mainCode.GDstartObjects1= [];
gdjs.mainCode.GDstartObjects2= [];
gdjs.mainCode.GDstartObjects3= [];
gdjs.mainCode.GDstartObjects4= [];
gdjs.mainCode.GDscoresObjects1= [];
gdjs.mainCode.GDscoresObjects2= [];
gdjs.mainCode.GDscoresObjects3= [];
gdjs.mainCode.GDscoresObjects4= [];
gdjs.mainCode.GDcreditsObjects1= [];
gdjs.mainCode.GDcreditsObjects2= [];
gdjs.mainCode.GDcreditsObjects3= [];
gdjs.mainCode.GDcreditsObjects4= [];


gdjs.mainCode.asyncCallback10856044 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("scroller_bg"), gdjs.mainCode.GDscroller_95bgObjects4);
{for(var i = 0, len = gdjs.mainCode.GDscroller_95bgObjects4.length ;i < len;++i) {
    gdjs.mainCode.GDscroller_95bgObjects4[i].getBehavior("Tween").addObjectPositionXTween("scroll_in", -(51), "linear", 500, false);
}
}}
gdjs.mainCode.eventsList0 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.mainCode.asyncCallback10856044(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.mainCode.asyncCallback10855348 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("credits"), gdjs.mainCode.GDcreditsObjects3);
{for(var i = 0, len = gdjs.mainCode.GDcreditsObjects3.length ;i < len;++i) {
    gdjs.mainCode.GDcreditsObjects3[i].getBehavior("Tween").addObjectPositionXTween("slide_in", 215, "linear", 500, false);
}
}
{ //Subevents
gdjs.mainCode.eventsList0(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.mainCode.eventsList1 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.mainCode.asyncCallback10855348(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.mainCode.asyncCallback10854572 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.mainCode.GDstartObjects2);
{for(var i = 0, len = gdjs.mainCode.GDstartObjects2.length ;i < len;++i) {
    gdjs.mainCode.GDstartObjects2[i].getBehavior("Tween").addObjectPositionXTween("slide_in", 215, "linear", 500, false);
}
}
{ //Subevents
gdjs.mainCode.eventsList1(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.mainCode.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.75), (runtimeScene) => (gdjs.mainCode.asyncCallback10854572(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.mainCode.asyncCallback10859748 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "guide", false);
}}
gdjs.mainCode.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.mainCode.asyncCallback10859748(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.mainCode.asyncCallback10864612 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "credits", false);
}}
gdjs.mainCode.eventsList4 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.mainCode.asyncCallback10864612(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.mainCode.asyncCallback13958956 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("scroller_text"), gdjs.mainCode.GDscroller_95textObjects2);
{for(var i = 0, len = gdjs.mainCode.GDscroller_95textObjects2.length ;i < len;++i) {
    gdjs.mainCode.GDscroller_95textObjects2[i].addForce(-(110), 0, 1);
}
}}
gdjs.mainCode.eventsList5 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.mainCode.asyncCallback13958956(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.mainCode.eventsList6 = function(runtimeScene) {

{



}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9290980);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "music\\OptimisticLoneliness.mp3", 100, true, 100, 1);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("title1"), gdjs.mainCode.GDtitle1Objects1);
gdjs.copyArray(runtimeScene.getObjects("title2"), gdjs.mainCode.GDtitle2Objects1);
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.mainCode.GDtransitionObjects1);
{for(var i = 0, len = gdjs.mainCode.GDtransitionObjects1.length ;i < len;++i) {
    gdjs.mainCode.GDtransitionObjects1[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.5, "Flash", "Backward", 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.mainCode.GDtitle1Objects1.length ;i < len;++i) {
    gdjs.mainCode.GDtitle1Objects1[i].getBehavior("Tween").addObjectPositionXTween("slide_in", 298, "linear", 750, false);
}
}{for(var i = 0, len = gdjs.mainCode.GDtitle2Objects1.length ;i < len;++i) {
    gdjs.mainCode.GDtitle2Objects1[i].getBehavior("Tween").addObjectPositionXTween("slide_in", 298, "linear", 750, false);
}
}
{ //Subevents
gdjs.mainCode.eventsList2(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("start"), gdjs.mainCode.GDstartObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mainCode.GDstartObjects1.length;i<l;++i) {
    if ( gdjs.mainCode.GDstartObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.mainCode.GDstartObjects1[k] = gdjs.mainCode.GDstartObjects1[i];
        ++k;
    }
}
gdjs.mainCode.GDstartObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10858428);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.mainCode.GDtransitionObjects1);
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "sound\\button.mp3", 100, false, 100, 1);
}{for(var i = 0, len = gdjs.mainCode.GDtransitionObjects1.length ;i < len;++i) {
    gdjs.mainCode.GDtransitionObjects1[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.5, "Circular", "Forward", 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.mainCode.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("credits"), gdjs.mainCode.GDcreditsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mainCode.GDcreditsObjects1.length;i<l;++i) {
    if ( gdjs.mainCode.GDcreditsObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.mainCode.GDcreditsObjects1[k] = gdjs.mainCode.GDcreditsObjects1[i];
        ++k;
    }
}
gdjs.mainCode.GDcreditsObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10863380);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.mainCode.GDtransitionObjects1);
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "sound\\button.mp3", 100, false, 100, 1);
}{for(var i = 0, len = gdjs.mainCode.GDtransitionObjects1.length ;i < len;++i) {
    gdjs.mainCode.GDtransitionObjects1[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.5, "Vertical", "Forward", 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.mainCode.eventsList4(runtimeScene);} //End of subevents
}

}


{



}


{



}


{



}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11471860);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.mainCode.eventsList5(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("scroller_text"), gdjs.mainCode.GDscroller_95textObjects1);
{for(var i = 0, len = gdjs.mainCode.GDscroller_95textObjects1.length ;i < len;++i) {
    gdjs.mainCode.GDscroller_95textObjects1[i].setBBText("Welcome to [b]TIMESHIFTER[/b] --- Made by Ikmal Said for the [b]GameDev.js Jam 2023[/b] with the theme [b]'Time'[/b] --- Thank You for Your Support :)");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("scroller_text"), gdjs.mainCode.GDscroller_95textObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mainCode.GDscroller_95textObjects1.length;i<l;++i) {
    if ( gdjs.mainCode.GDscroller_95textObjects1[i].getX() <= -(((gdjs.mainCode.GDscroller_95textObjects1[i].getWidth()))) ) {
        isConditionTrue_0 = true;
        gdjs.mainCode.GDscroller_95textObjects1[k] = gdjs.mainCode.GDscroller_95textObjects1[i];
        ++k;
    }
}
gdjs.mainCode.GDscroller_95textObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.mainCode.GDscroller_95textObjects1 */
{for(var i = 0, len = gdjs.mainCode.GDscroller_95textObjects1.length ;i < len;++i) {
    gdjs.mainCode.GDscroller_95textObjects1[i].setX(1200);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("moving_bg"), gdjs.mainCode.GDmoving_95bgObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mainCode.GDmoving_95bgObjects1.length;i<l;++i) {
    if ( gdjs.mainCode.GDmoving_95bgObjects1[i].getXOffset() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.mainCode.GDmoving_95bgObjects1[k] = gdjs.mainCode.GDmoving_95bgObjects1[i];
        ++k;
    }
}
gdjs.mainCode.GDmoving_95bgObjects1.length = k;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(gdjs.randomInRange(-(2), 2));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("moving_bg"), gdjs.mainCode.GDmoving_95bgObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mainCode.GDmoving_95bgObjects1.length;i<l;++i) {
    if ( gdjs.mainCode.GDmoving_95bgObjects1[i].getYOffset() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.mainCode.GDmoving_95bgObjects1[k] = gdjs.mainCode.GDmoving_95bgObjects1[i];
        ++k;
    }
}
gdjs.mainCode.GDmoving_95bgObjects1.length = k;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(gdjs.randomInRange(-(2), 2));
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("moving_bg"), gdjs.mainCode.GDmoving_95bgObjects1);
{for(var i = 0, len = gdjs.mainCode.GDmoving_95bgObjects1.length ;i < len;++i) {
    gdjs.mainCode.GDmoving_95bgObjects1[i].setXOffset(gdjs.mainCode.GDmoving_95bgObjects1[i].getXOffset() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))));
}
}{for(var i = 0, len = gdjs.mainCode.GDmoving_95bgObjects1.length ;i < len;++i) {
    gdjs.mainCode.GDmoving_95bgObjects1[i].setYOffset(gdjs.mainCode.GDmoving_95bgObjects1[i].getYOffset() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};

gdjs.mainCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.mainCode.GDtransitionObjects1.length = 0;
gdjs.mainCode.GDtransitionObjects2.length = 0;
gdjs.mainCode.GDtransitionObjects3.length = 0;
gdjs.mainCode.GDtransitionObjects4.length = 0;
gdjs.mainCode.GDblackscreenObjects1.length = 0;
gdjs.mainCode.GDblackscreenObjects2.length = 0;
gdjs.mainCode.GDblackscreenObjects3.length = 0;
gdjs.mainCode.GDblackscreenObjects4.length = 0;
gdjs.mainCode.GDtitle_95bgObjects1.length = 0;
gdjs.mainCode.GDtitle_95bgObjects2.length = 0;
gdjs.mainCode.GDtitle_95bgObjects3.length = 0;
gdjs.mainCode.GDtitle_95bgObjects4.length = 0;
gdjs.mainCode.GDtitle_95fgObjects1.length = 0;
gdjs.mainCode.GDtitle_95fgObjects2.length = 0;
gdjs.mainCode.GDtitle_95fgObjects3.length = 0;
gdjs.mainCode.GDtitle_95fgObjects4.length = 0;
gdjs.mainCode.GDred_95buttonObjects1.length = 0;
gdjs.mainCode.GDred_95buttonObjects2.length = 0;
gdjs.mainCode.GDred_95buttonObjects3.length = 0;
gdjs.mainCode.GDred_95buttonObjects4.length = 0;
gdjs.mainCode.GDgreen_95buttonObjects1.length = 0;
gdjs.mainCode.GDgreen_95buttonObjects2.length = 0;
gdjs.mainCode.GDgreen_95buttonObjects3.length = 0;
gdjs.mainCode.GDgreen_95buttonObjects4.length = 0;
gdjs.mainCode.GDmoving_95bgObjects1.length = 0;
gdjs.mainCode.GDmoving_95bgObjects2.length = 0;
gdjs.mainCode.GDmoving_95bgObjects3.length = 0;
gdjs.mainCode.GDmoving_95bgObjects4.length = 0;
gdjs.mainCode.GDscroller_95bgObjects1.length = 0;
gdjs.mainCode.GDscroller_95bgObjects2.length = 0;
gdjs.mainCode.GDscroller_95bgObjects3.length = 0;
gdjs.mainCode.GDscroller_95bgObjects4.length = 0;
gdjs.mainCode.GDscroller_95textObjects1.length = 0;
gdjs.mainCode.GDscroller_95textObjects2.length = 0;
gdjs.mainCode.GDscroller_95textObjects3.length = 0;
gdjs.mainCode.GDscroller_95textObjects4.length = 0;
gdjs.mainCode.GDtitle1Objects1.length = 0;
gdjs.mainCode.GDtitle1Objects2.length = 0;
gdjs.mainCode.GDtitle1Objects3.length = 0;
gdjs.mainCode.GDtitle1Objects4.length = 0;
gdjs.mainCode.GDtitle2Objects1.length = 0;
gdjs.mainCode.GDtitle2Objects2.length = 0;
gdjs.mainCode.GDtitle2Objects3.length = 0;
gdjs.mainCode.GDtitle2Objects4.length = 0;
gdjs.mainCode.GDstartObjects1.length = 0;
gdjs.mainCode.GDstartObjects2.length = 0;
gdjs.mainCode.GDstartObjects3.length = 0;
gdjs.mainCode.GDstartObjects4.length = 0;
gdjs.mainCode.GDscoresObjects1.length = 0;
gdjs.mainCode.GDscoresObjects2.length = 0;
gdjs.mainCode.GDscoresObjects3.length = 0;
gdjs.mainCode.GDscoresObjects4.length = 0;
gdjs.mainCode.GDcreditsObjects1.length = 0;
gdjs.mainCode.GDcreditsObjects2.length = 0;
gdjs.mainCode.GDcreditsObjects3.length = 0;
gdjs.mainCode.GDcreditsObjects4.length = 0;

gdjs.mainCode.eventsList6(runtimeScene);

return;

}

gdjs['mainCode'] = gdjs.mainCode;

gdjs.levelsCode = {};
gdjs.levelsCode.GDtransitionObjects1= [];
gdjs.levelsCode.GDtransitionObjects2= [];
gdjs.levelsCode.GDtransitionObjects3= [];
gdjs.levelsCode.GDtransitionObjects4= [];
gdjs.levelsCode.GDtransitionObjects5= [];
gdjs.levelsCode.GDtransitionObjects6= [];
gdjs.levelsCode.GDtransitionObjects7= [];
gdjs.levelsCode.GDblackscreenObjects1= [];
gdjs.levelsCode.GDblackscreenObjects2= [];
gdjs.levelsCode.GDblackscreenObjects3= [];
gdjs.levelsCode.GDblackscreenObjects4= [];
gdjs.levelsCode.GDblackscreenObjects5= [];
gdjs.levelsCode.GDblackscreenObjects6= [];
gdjs.levelsCode.GDblackscreenObjects7= [];
gdjs.levelsCode.GDtitle_95bgObjects1= [];
gdjs.levelsCode.GDtitle_95bgObjects2= [];
gdjs.levelsCode.GDtitle_95bgObjects3= [];
gdjs.levelsCode.GDtitle_95bgObjects4= [];
gdjs.levelsCode.GDtitle_95bgObjects5= [];
gdjs.levelsCode.GDtitle_95bgObjects6= [];
gdjs.levelsCode.GDtitle_95bgObjects7= [];
gdjs.levelsCode.GDtitle_95fgObjects1= [];
gdjs.levelsCode.GDtitle_95fgObjects2= [];
gdjs.levelsCode.GDtitle_95fgObjects3= [];
gdjs.levelsCode.GDtitle_95fgObjects4= [];
gdjs.levelsCode.GDtitle_95fgObjects5= [];
gdjs.levelsCode.GDtitle_95fgObjects6= [];
gdjs.levelsCode.GDtitle_95fgObjects7= [];
gdjs.levelsCode.GDred_95buttonObjects1= [];
gdjs.levelsCode.GDred_95buttonObjects2= [];
gdjs.levelsCode.GDred_95buttonObjects3= [];
gdjs.levelsCode.GDred_95buttonObjects4= [];
gdjs.levelsCode.GDred_95buttonObjects5= [];
gdjs.levelsCode.GDred_95buttonObjects6= [];
gdjs.levelsCode.GDred_95buttonObjects7= [];
gdjs.levelsCode.GDgreen_95buttonObjects1= [];
gdjs.levelsCode.GDgreen_95buttonObjects2= [];
gdjs.levelsCode.GDgreen_95buttonObjects3= [];
gdjs.levelsCode.GDgreen_95buttonObjects4= [];
gdjs.levelsCode.GDgreen_95buttonObjects5= [];
gdjs.levelsCode.GDgreen_95buttonObjects6= [];
gdjs.levelsCode.GDgreen_95buttonObjects7= [];
gdjs.levelsCode.GDmoving_95bgObjects1= [];
gdjs.levelsCode.GDmoving_95bgObjects2= [];
gdjs.levelsCode.GDmoving_95bgObjects3= [];
gdjs.levelsCode.GDmoving_95bgObjects4= [];
gdjs.levelsCode.GDmoving_95bgObjects5= [];
gdjs.levelsCode.GDmoving_95bgObjects6= [];
gdjs.levelsCode.GDmoving_95bgObjects7= [];
gdjs.levelsCode.GDplayerObjects1= [];
gdjs.levelsCode.GDplayerObjects2= [];
gdjs.levelsCode.GDplayerObjects3= [];
gdjs.levelsCode.GDplayerObjects4= [];
gdjs.levelsCode.GDplayerObjects5= [];
gdjs.levelsCode.GDplayerObjects6= [];
gdjs.levelsCode.GDplayerObjects7= [];
gdjs.levelsCode.GDnext_95levelObjects1= [];
gdjs.levelsCode.GDnext_95levelObjects2= [];
gdjs.levelsCode.GDnext_95levelObjects3= [];
gdjs.levelsCode.GDnext_95levelObjects4= [];
gdjs.levelsCode.GDnext_95levelObjects5= [];
gdjs.levelsCode.GDnext_95levelObjects6= [];
gdjs.levelsCode.GDnext_95levelObjects7= [];
gdjs.levelsCode.GDresetObjects1= [];
gdjs.levelsCode.GDresetObjects2= [];
gdjs.levelsCode.GDresetObjects3= [];
gdjs.levelsCode.GDresetObjects4= [];
gdjs.levelsCode.GDresetObjects5= [];
gdjs.levelsCode.GDresetObjects6= [];
gdjs.levelsCode.GDresetObjects7= [];
gdjs.levelsCode.GDsoundObjects1= [];
gdjs.levelsCode.GDsoundObjects2= [];
gdjs.levelsCode.GDsoundObjects3= [];
gdjs.levelsCode.GDsoundObjects4= [];
gdjs.levelsCode.GDsoundObjects5= [];
gdjs.levelsCode.GDsoundObjects6= [];
gdjs.levelsCode.GDsoundObjects7= [];
gdjs.levelsCode.GDexitObjects1= [];
gdjs.levelsCode.GDexitObjects2= [];
gdjs.levelsCode.GDexitObjects3= [];
gdjs.levelsCode.GDexitObjects4= [];
gdjs.levelsCode.GDexitObjects5= [];
gdjs.levelsCode.GDexitObjects6= [];
gdjs.levelsCode.GDexitObjects7= [];
gdjs.levelsCode.GDtry_95againObjects1= [];
gdjs.levelsCode.GDtry_95againObjects2= [];
gdjs.levelsCode.GDtry_95againObjects3= [];
gdjs.levelsCode.GDtry_95againObjects4= [];
gdjs.levelsCode.GDtry_95againObjects5= [];
gdjs.levelsCode.GDtry_95againObjects6= [];
gdjs.levelsCode.GDtry_95againObjects7= [];
gdjs.levelsCode.GDquit_95gameObjects1= [];
gdjs.levelsCode.GDquit_95gameObjects2= [];
gdjs.levelsCode.GDquit_95gameObjects3= [];
gdjs.levelsCode.GDquit_95gameObjects4= [];
gdjs.levelsCode.GDquit_95gameObjects5= [];
gdjs.levelsCode.GDquit_95gameObjects6= [];
gdjs.levelsCode.GDquit_95gameObjects7= [];
gdjs.levelsCode.GDlevel_95completeObjects1= [];
gdjs.levelsCode.GDlevel_95completeObjects2= [];
gdjs.levelsCode.GDlevel_95completeObjects3= [];
gdjs.levelsCode.GDlevel_95completeObjects4= [];
gdjs.levelsCode.GDlevel_95completeObjects5= [];
gdjs.levelsCode.GDlevel_95completeObjects6= [];
gdjs.levelsCode.GDlevel_95completeObjects7= [];
gdjs.levelsCode.GDtime_95outObjects1= [];
gdjs.levelsCode.GDtime_95outObjects2= [];
gdjs.levelsCode.GDtime_95outObjects3= [];
gdjs.levelsCode.GDtime_95outObjects4= [];
gdjs.levelsCode.GDtime_95outObjects5= [];
gdjs.levelsCode.GDtime_95outObjects6= [];
gdjs.levelsCode.GDtime_95outObjects7= [];
gdjs.levelsCode.GDplayer_95total_95scoreObjects1= [];
gdjs.levelsCode.GDplayer_95total_95scoreObjects2= [];
gdjs.levelsCode.GDplayer_95total_95scoreObjects3= [];
gdjs.levelsCode.GDplayer_95total_95scoreObjects4= [];
gdjs.levelsCode.GDplayer_95total_95scoreObjects5= [];
gdjs.levelsCode.GDplayer_95total_95scoreObjects6= [];
gdjs.levelsCode.GDplayer_95total_95scoreObjects7= [];
gdjs.levelsCode.GDgame_95timeObjects1= [];
gdjs.levelsCode.GDgame_95timeObjects2= [];
gdjs.levelsCode.GDgame_95timeObjects3= [];
gdjs.levelsCode.GDgame_95timeObjects4= [];
gdjs.levelsCode.GDgame_95timeObjects5= [];
gdjs.levelsCode.GDgame_95timeObjects6= [];
gdjs.levelsCode.GDgame_95timeObjects7= [];
gdjs.levelsCode.GDcontrolsObjects1= [];
gdjs.levelsCode.GDcontrolsObjects2= [];
gdjs.levelsCode.GDcontrolsObjects3= [];
gdjs.levelsCode.GDcontrolsObjects4= [];
gdjs.levelsCode.GDcontrolsObjects5= [];
gdjs.levelsCode.GDcontrolsObjects6= [];
gdjs.levelsCode.GDcontrolsObjects7= [];
gdjs.levelsCode.GDdebugtextObjects1= [];
gdjs.levelsCode.GDdebugtextObjects2= [];
gdjs.levelsCode.GDdebugtextObjects3= [];
gdjs.levelsCode.GDdebugtextObjects4= [];
gdjs.levelsCode.GDdebugtextObjects5= [];
gdjs.levelsCode.GDdebugtextObjects6= [];
gdjs.levelsCode.GDdebugtextObjects7= [];
gdjs.levelsCode.GDdebugtext_95xObjects1= [];
gdjs.levelsCode.GDdebugtext_95xObjects2= [];
gdjs.levelsCode.GDdebugtext_95xObjects3= [];
gdjs.levelsCode.GDdebugtext_95xObjects4= [];
gdjs.levelsCode.GDdebugtext_95xObjects5= [];
gdjs.levelsCode.GDdebugtext_95xObjects6= [];
gdjs.levelsCode.GDdebugtext_95xObjects7= [];
gdjs.levelsCode.GDdebugtext_95yObjects1= [];
gdjs.levelsCode.GDdebugtext_95yObjects2= [];
gdjs.levelsCode.GDdebugtext_95yObjects3= [];
gdjs.levelsCode.GDdebugtext_95yObjects4= [];
gdjs.levelsCode.GDdebugtext_95yObjects5= [];
gdjs.levelsCode.GDdebugtext_95yObjects6= [];
gdjs.levelsCode.GDdebugtext_95yObjects7= [];
gdjs.levelsCode.GDRoundSliderObjects1= [];
gdjs.levelsCode.GDRoundSliderObjects2= [];
gdjs.levelsCode.GDRoundSliderObjects3= [];
gdjs.levelsCode.GDRoundSliderObjects4= [];
gdjs.levelsCode.GDRoundSliderObjects5= [];
gdjs.levelsCode.GDRoundSliderObjects6= [];
gdjs.levelsCode.GDRoundSliderObjects7= [];
gdjs.levelsCode.GDRoundSlider2Objects1= [];
gdjs.levelsCode.GDRoundSlider2Objects2= [];
gdjs.levelsCode.GDRoundSlider2Objects3= [];
gdjs.levelsCode.GDRoundSlider2Objects4= [];
gdjs.levelsCode.GDRoundSlider2Objects5= [];
gdjs.levelsCode.GDRoundSlider2Objects6= [];
gdjs.levelsCode.GDRoundSlider2Objects7= [];
gdjs.levelsCode.GDRoundSlider3Objects1= [];
gdjs.levelsCode.GDRoundSlider3Objects2= [];
gdjs.levelsCode.GDRoundSlider3Objects3= [];
gdjs.levelsCode.GDRoundSlider3Objects4= [];
gdjs.levelsCode.GDRoundSlider3Objects5= [];
gdjs.levelsCode.GDRoundSlider3Objects6= [];
gdjs.levelsCode.GDRoundSlider3Objects7= [];
gdjs.levelsCode.GDlevel_95mapObjects1= [];
gdjs.levelsCode.GDlevel_95mapObjects2= [];
gdjs.levelsCode.GDlevel_95mapObjects3= [];
gdjs.levelsCode.GDlevel_95mapObjects4= [];
gdjs.levelsCode.GDlevel_95mapObjects5= [];
gdjs.levelsCode.GDlevel_95mapObjects6= [];
gdjs.levelsCode.GDlevel_95mapObjects7= [];
gdjs.levelsCode.GDlevel_95wallObjects1= [];
gdjs.levelsCode.GDlevel_95wallObjects2= [];
gdjs.levelsCode.GDlevel_95wallObjects3= [];
gdjs.levelsCode.GDlevel_95wallObjects4= [];
gdjs.levelsCode.GDlevel_95wallObjects5= [];
gdjs.levelsCode.GDlevel_95wallObjects6= [];
gdjs.levelsCode.GDlevel_95wallObjects7= [];
gdjs.levelsCode.GDlevel_95rcdObjects1= [];
gdjs.levelsCode.GDlevel_95rcdObjects2= [];
gdjs.levelsCode.GDlevel_95rcdObjects3= [];
gdjs.levelsCode.GDlevel_95rcdObjects4= [];
gdjs.levelsCode.GDlevel_95rcdObjects5= [];
gdjs.levelsCode.GDlevel_95rcdObjects6= [];
gdjs.levelsCode.GDlevel_95rcdObjects7= [];
gdjs.levelsCode.GDlevel_95gcdObjects1= [];
gdjs.levelsCode.GDlevel_95gcdObjects2= [];
gdjs.levelsCode.GDlevel_95gcdObjects3= [];
gdjs.levelsCode.GDlevel_95gcdObjects4= [];
gdjs.levelsCode.GDlevel_95gcdObjects5= [];
gdjs.levelsCode.GDlevel_95gcdObjects6= [];
gdjs.levelsCode.GDlevel_95gcdObjects7= [];
gdjs.levelsCode.GDlevel_95bcdObjects1= [];
gdjs.levelsCode.GDlevel_95bcdObjects2= [];
gdjs.levelsCode.GDlevel_95bcdObjects3= [];
gdjs.levelsCode.GDlevel_95bcdObjects4= [];
gdjs.levelsCode.GDlevel_95bcdObjects5= [];
gdjs.levelsCode.GDlevel_95bcdObjects6= [];
gdjs.levelsCode.GDlevel_95bcdObjects7= [];
gdjs.levelsCode.GDlevel_95rsdObjects1= [];
gdjs.levelsCode.GDlevel_95rsdObjects2= [];
gdjs.levelsCode.GDlevel_95rsdObjects3= [];
gdjs.levelsCode.GDlevel_95rsdObjects4= [];
gdjs.levelsCode.GDlevel_95rsdObjects5= [];
gdjs.levelsCode.GDlevel_95rsdObjects6= [];
gdjs.levelsCode.GDlevel_95rsdObjects7= [];
gdjs.levelsCode.GDlevel_95gsdObjects1= [];
gdjs.levelsCode.GDlevel_95gsdObjects2= [];
gdjs.levelsCode.GDlevel_95gsdObjects3= [];
gdjs.levelsCode.GDlevel_95gsdObjects4= [];
gdjs.levelsCode.GDlevel_95gsdObjects5= [];
gdjs.levelsCode.GDlevel_95gsdObjects6= [];
gdjs.levelsCode.GDlevel_95gsdObjects7= [];
gdjs.levelsCode.GDlevel_95bsdObjects1= [];
gdjs.levelsCode.GDlevel_95bsdObjects2= [];
gdjs.levelsCode.GDlevel_95bsdObjects3= [];
gdjs.levelsCode.GDlevel_95bsdObjects4= [];
gdjs.levelsCode.GDlevel_95bsdObjects5= [];
gdjs.levelsCode.GDlevel_95bsdObjects6= [];
gdjs.levelsCode.GDlevel_95bsdObjects7= [];
gdjs.levelsCode.GDlevel_95rtdObjects1= [];
gdjs.levelsCode.GDlevel_95rtdObjects2= [];
gdjs.levelsCode.GDlevel_95rtdObjects3= [];
gdjs.levelsCode.GDlevel_95rtdObjects4= [];
gdjs.levelsCode.GDlevel_95rtdObjects5= [];
gdjs.levelsCode.GDlevel_95rtdObjects6= [];
gdjs.levelsCode.GDlevel_95rtdObjects7= [];
gdjs.levelsCode.GDlevel_95gtdObjects1= [];
gdjs.levelsCode.GDlevel_95gtdObjects2= [];
gdjs.levelsCode.GDlevel_95gtdObjects3= [];
gdjs.levelsCode.GDlevel_95gtdObjects4= [];
gdjs.levelsCode.GDlevel_95gtdObjects5= [];
gdjs.levelsCode.GDlevel_95gtdObjects6= [];
gdjs.levelsCode.GDlevel_95gtdObjects7= [];
gdjs.levelsCode.GDlevel_95btdObjects1= [];
gdjs.levelsCode.GDlevel_95btdObjects2= [];
gdjs.levelsCode.GDlevel_95btdObjects3= [];
gdjs.levelsCode.GDlevel_95btdObjects4= [];
gdjs.levelsCode.GDlevel_95btdObjects5= [];
gdjs.levelsCode.GDlevel_95btdObjects6= [];
gdjs.levelsCode.GDlevel_95btdObjects7= [];
gdjs.levelsCode.GDlevel_95rdObjects1= [];
gdjs.levelsCode.GDlevel_95rdObjects2= [];
gdjs.levelsCode.GDlevel_95rdObjects3= [];
gdjs.levelsCode.GDlevel_95rdObjects4= [];
gdjs.levelsCode.GDlevel_95rdObjects5= [];
gdjs.levelsCode.GDlevel_95rdObjects6= [];
gdjs.levelsCode.GDlevel_95rdObjects7= [];
gdjs.levelsCode.GDlevel_95gdObjects1= [];
gdjs.levelsCode.GDlevel_95gdObjects2= [];
gdjs.levelsCode.GDlevel_95gdObjects3= [];
gdjs.levelsCode.GDlevel_95gdObjects4= [];
gdjs.levelsCode.GDlevel_95gdObjects5= [];
gdjs.levelsCode.GDlevel_95gdObjects6= [];
gdjs.levelsCode.GDlevel_95gdObjects7= [];
gdjs.levelsCode.GDlevel_95bdObjects1= [];
gdjs.levelsCode.GDlevel_95bdObjects2= [];
gdjs.levelsCode.GDlevel_95bdObjects3= [];
gdjs.levelsCode.GDlevel_95bdObjects4= [];
gdjs.levelsCode.GDlevel_95bdObjects5= [];
gdjs.levelsCode.GDlevel_95bdObjects6= [];
gdjs.levelsCode.GDlevel_95bdObjects7= [];
gdjs.levelsCode.GDlevel_95rcpObjects1= [];
gdjs.levelsCode.GDlevel_95rcpObjects2= [];
gdjs.levelsCode.GDlevel_95rcpObjects3= [];
gdjs.levelsCode.GDlevel_95rcpObjects4= [];
gdjs.levelsCode.GDlevel_95rcpObjects5= [];
gdjs.levelsCode.GDlevel_95rcpObjects6= [];
gdjs.levelsCode.GDlevel_95rcpObjects7= [];
gdjs.levelsCode.GDlevel_95gcpObjects1= [];
gdjs.levelsCode.GDlevel_95gcpObjects2= [];
gdjs.levelsCode.GDlevel_95gcpObjects3= [];
gdjs.levelsCode.GDlevel_95gcpObjects4= [];
gdjs.levelsCode.GDlevel_95gcpObjects5= [];
gdjs.levelsCode.GDlevel_95gcpObjects6= [];
gdjs.levelsCode.GDlevel_95gcpObjects7= [];
gdjs.levelsCode.GDlevel_95bcpObjects1= [];
gdjs.levelsCode.GDlevel_95bcpObjects2= [];
gdjs.levelsCode.GDlevel_95bcpObjects3= [];
gdjs.levelsCode.GDlevel_95bcpObjects4= [];
gdjs.levelsCode.GDlevel_95bcpObjects5= [];
gdjs.levelsCode.GDlevel_95bcpObjects6= [];
gdjs.levelsCode.GDlevel_95bcpObjects7= [];
gdjs.levelsCode.GDlevel_95rspObjects1= [];
gdjs.levelsCode.GDlevel_95rspObjects2= [];
gdjs.levelsCode.GDlevel_95rspObjects3= [];
gdjs.levelsCode.GDlevel_95rspObjects4= [];
gdjs.levelsCode.GDlevel_95rspObjects5= [];
gdjs.levelsCode.GDlevel_95rspObjects6= [];
gdjs.levelsCode.GDlevel_95rspObjects7= [];
gdjs.levelsCode.GDlevel_95gspObjects1= [];
gdjs.levelsCode.GDlevel_95gspObjects2= [];
gdjs.levelsCode.GDlevel_95gspObjects3= [];
gdjs.levelsCode.GDlevel_95gspObjects4= [];
gdjs.levelsCode.GDlevel_95gspObjects5= [];
gdjs.levelsCode.GDlevel_95gspObjects6= [];
gdjs.levelsCode.GDlevel_95gspObjects7= [];
gdjs.levelsCode.GDlevel_95bspObjects1= [];
gdjs.levelsCode.GDlevel_95bspObjects2= [];
gdjs.levelsCode.GDlevel_95bspObjects3= [];
gdjs.levelsCode.GDlevel_95bspObjects4= [];
gdjs.levelsCode.GDlevel_95bspObjects5= [];
gdjs.levelsCode.GDlevel_95bspObjects6= [];
gdjs.levelsCode.GDlevel_95bspObjects7= [];
gdjs.levelsCode.GDlevel_95rtpObjects1= [];
gdjs.levelsCode.GDlevel_95rtpObjects2= [];
gdjs.levelsCode.GDlevel_95rtpObjects3= [];
gdjs.levelsCode.GDlevel_95rtpObjects4= [];
gdjs.levelsCode.GDlevel_95rtpObjects5= [];
gdjs.levelsCode.GDlevel_95rtpObjects6= [];
gdjs.levelsCode.GDlevel_95rtpObjects7= [];
gdjs.levelsCode.GDlevel_95gtpObjects1= [];
gdjs.levelsCode.GDlevel_95gtpObjects2= [];
gdjs.levelsCode.GDlevel_95gtpObjects3= [];
gdjs.levelsCode.GDlevel_95gtpObjects4= [];
gdjs.levelsCode.GDlevel_95gtpObjects5= [];
gdjs.levelsCode.GDlevel_95gtpObjects6= [];
gdjs.levelsCode.GDlevel_95gtpObjects7= [];
gdjs.levelsCode.GDlevel_95btpObjects1= [];
gdjs.levelsCode.GDlevel_95btpObjects2= [];
gdjs.levelsCode.GDlevel_95btpObjects3= [];
gdjs.levelsCode.GDlevel_95btpObjects4= [];
gdjs.levelsCode.GDlevel_95btpObjects5= [];
gdjs.levelsCode.GDlevel_95btpObjects6= [];
gdjs.levelsCode.GDlevel_95btpObjects7= [];
gdjs.levelsCode.GDlevel_95rpObjects1= [];
gdjs.levelsCode.GDlevel_95rpObjects2= [];
gdjs.levelsCode.GDlevel_95rpObjects3= [];
gdjs.levelsCode.GDlevel_95rpObjects4= [];
gdjs.levelsCode.GDlevel_95rpObjects5= [];
gdjs.levelsCode.GDlevel_95rpObjects6= [];
gdjs.levelsCode.GDlevel_95rpObjects7= [];
gdjs.levelsCode.GDlevel_95gpObjects1= [];
gdjs.levelsCode.GDlevel_95gpObjects2= [];
gdjs.levelsCode.GDlevel_95gpObjects3= [];
gdjs.levelsCode.GDlevel_95gpObjects4= [];
gdjs.levelsCode.GDlevel_95gpObjects5= [];
gdjs.levelsCode.GDlevel_95gpObjects6= [];
gdjs.levelsCode.GDlevel_95gpObjects7= [];
gdjs.levelsCode.GDlevel_95bpObjects1= [];
gdjs.levelsCode.GDlevel_95bpObjects2= [];
gdjs.levelsCode.GDlevel_95bpObjects3= [];
gdjs.levelsCode.GDlevel_95bpObjects4= [];
gdjs.levelsCode.GDlevel_95bpObjects5= [];
gdjs.levelsCode.GDlevel_95bpObjects6= [];
gdjs.levelsCode.GDlevel_95bpObjects7= [];
gdjs.levelsCode.GDlevel_95cpObjects1= [];
gdjs.levelsCode.GDlevel_95cpObjects2= [];
gdjs.levelsCode.GDlevel_95cpObjects3= [];
gdjs.levelsCode.GDlevel_95cpObjects4= [];
gdjs.levelsCode.GDlevel_95cpObjects5= [];
gdjs.levelsCode.GDlevel_95cpObjects6= [];
gdjs.levelsCode.GDlevel_95cpObjects7= [];
gdjs.levelsCode.GDlevel_95spObjects1= [];
gdjs.levelsCode.GDlevel_95spObjects2= [];
gdjs.levelsCode.GDlevel_95spObjects3= [];
gdjs.levelsCode.GDlevel_95spObjects4= [];
gdjs.levelsCode.GDlevel_95spObjects5= [];
gdjs.levelsCode.GDlevel_95spObjects6= [];
gdjs.levelsCode.GDlevel_95spObjects7= [];
gdjs.levelsCode.GDlevel_95tpObjects1= [];
gdjs.levelsCode.GDlevel_95tpObjects2= [];
gdjs.levelsCode.GDlevel_95tpObjects3= [];
gdjs.levelsCode.GDlevel_95tpObjects4= [];
gdjs.levelsCode.GDlevel_95tpObjects5= [];
gdjs.levelsCode.GDlevel_95tpObjects6= [];
gdjs.levelsCode.GDlevel_95tpObjects7= [];
gdjs.levelsCode.GDlevel_95cdObjects1= [];
gdjs.levelsCode.GDlevel_95cdObjects2= [];
gdjs.levelsCode.GDlevel_95cdObjects3= [];
gdjs.levelsCode.GDlevel_95cdObjects4= [];
gdjs.levelsCode.GDlevel_95cdObjects5= [];
gdjs.levelsCode.GDlevel_95cdObjects6= [];
gdjs.levelsCode.GDlevel_95cdObjects7= [];
gdjs.levelsCode.GDlevel_95sdObjects1= [];
gdjs.levelsCode.GDlevel_95sdObjects2= [];
gdjs.levelsCode.GDlevel_95sdObjects3= [];
gdjs.levelsCode.GDlevel_95sdObjects4= [];
gdjs.levelsCode.GDlevel_95sdObjects5= [];
gdjs.levelsCode.GDlevel_95sdObjects6= [];
gdjs.levelsCode.GDlevel_95sdObjects7= [];
gdjs.levelsCode.GDlevel_95tdObjects1= [];
gdjs.levelsCode.GDlevel_95tdObjects2= [];
gdjs.levelsCode.GDlevel_95tdObjects3= [];
gdjs.levelsCode.GDlevel_95tdObjects4= [];
gdjs.levelsCode.GDlevel_95tdObjects5= [];
gdjs.levelsCode.GDlevel_95tdObjects6= [];
gdjs.levelsCode.GDlevel_95tdObjects7= [];
gdjs.levelsCode.GDlevel_95starObjects1= [];
gdjs.levelsCode.GDlevel_95starObjects2= [];
gdjs.levelsCode.GDlevel_95starObjects3= [];
gdjs.levelsCode.GDlevel_95starObjects4= [];
gdjs.levelsCode.GDlevel_95starObjects5= [];
gdjs.levelsCode.GDlevel_95starObjects6= [];
gdjs.levelsCode.GDlevel_95starObjects7= [];
gdjs.levelsCode.GDstart_95positionObjects1= [];
gdjs.levelsCode.GDstart_95positionObjects2= [];
gdjs.levelsCode.GDstart_95positionObjects3= [];
gdjs.levelsCode.GDstart_95positionObjects4= [];
gdjs.levelsCode.GDstart_95positionObjects5= [];
gdjs.levelsCode.GDstart_95positionObjects6= [];
gdjs.levelsCode.GDstart_95positionObjects7= [];
gdjs.levelsCode.GDlevel_95bgObjects1= [];
gdjs.levelsCode.GDlevel_95bgObjects2= [];
gdjs.levelsCode.GDlevel_95bgObjects3= [];
gdjs.levelsCode.GDlevel_95bgObjects4= [];
gdjs.levelsCode.GDlevel_95bgObjects5= [];
gdjs.levelsCode.GDlevel_95bgObjects6= [];
gdjs.levelsCode.GDlevel_95bgObjects7= [];
gdjs.levelsCode.GDwhite_95borderObjects1= [];
gdjs.levelsCode.GDwhite_95borderObjects2= [];
gdjs.levelsCode.GDwhite_95borderObjects3= [];
gdjs.levelsCode.GDwhite_95borderObjects4= [];
gdjs.levelsCode.GDwhite_95borderObjects5= [];
gdjs.levelsCode.GDwhite_95borderObjects6= [];
gdjs.levelsCode.GDwhite_95borderObjects7= [];


gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.levelsCode.GDplayerObjects1});
gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595wallObjects1Objects = Hashtable.newFrom({"level_wall": gdjs.levelsCode.GDlevel_95wallObjects1});
gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595wallObjects1Objects = Hashtable.newFrom({"level_wall": gdjs.levelsCode.GDlevel_95wallObjects1});
gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.levelsCode.GDplayerObjects1});
gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595starObjects1Objects = Hashtable.newFrom({"level_star": gdjs.levelsCode.GDlevel_95starObjects1});
gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.levelsCode.GDplayerObjects1});
gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595rcdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595rsdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595rtdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595rdObjects1Objects = Hashtable.newFrom({"level_rcd": gdjs.levelsCode.GDlevel_95rcdObjects1, "level_rsd": gdjs.levelsCode.GDlevel_95rsdObjects1, "level_rtd": gdjs.levelsCode.GDlevel_95rtdObjects1, "level_rd": gdjs.levelsCode.GDlevel_95rdObjects1});
gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595rcdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595rsdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595rtdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595rdObjects1Objects = Hashtable.newFrom({"level_rcd": gdjs.levelsCode.GDlevel_95rcdObjects1, "level_rsd": gdjs.levelsCode.GDlevel_95rsdObjects1, "level_rtd": gdjs.levelsCode.GDlevel_95rtdObjects1, "level_rd": gdjs.levelsCode.GDlevel_95rdObjects1});
gdjs.levelsCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12152004);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "sound\\reject.mp3", 100, false, 100, 1);
}}

}


};gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.levelsCode.GDplayerObjects1});
gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595gcdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595gsdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595gtdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595gdObjects1Objects = Hashtable.newFrom({"level_gcd": gdjs.levelsCode.GDlevel_95gcdObjects1, "level_gsd": gdjs.levelsCode.GDlevel_95gsdObjects1, "level_gtd": gdjs.levelsCode.GDlevel_95gtdObjects1, "level_gd": gdjs.levelsCode.GDlevel_95gdObjects1});
gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595gcdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595gsdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595gtdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595gdObjects1Objects = Hashtable.newFrom({"level_gcd": gdjs.levelsCode.GDlevel_95gcdObjects1, "level_gsd": gdjs.levelsCode.GDlevel_95gsdObjects1, "level_gtd": gdjs.levelsCode.GDlevel_95gtdObjects1, "level_gd": gdjs.levelsCode.GDlevel_95gdObjects1});
gdjs.levelsCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10860420);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "sound\\reject.mp3", 100, false, 100, 1);
}}

}


};gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.levelsCode.GDplayerObjects1});
gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595bcdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595bsdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595btdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595bdObjects1Objects = Hashtable.newFrom({"level_bcd": gdjs.levelsCode.GDlevel_95bcdObjects1, "level_bsd": gdjs.levelsCode.GDlevel_95bsdObjects1, "level_btd": gdjs.levelsCode.GDlevel_95btdObjects1, "level_bd": gdjs.levelsCode.GDlevel_95bdObjects1});
gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595bcdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595bsdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595btdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595bdObjects1Objects = Hashtable.newFrom({"level_bcd": gdjs.levelsCode.GDlevel_95bcdObjects1, "level_bsd": gdjs.levelsCode.GDlevel_95bsdObjects1, "level_btd": gdjs.levelsCode.GDlevel_95btdObjects1, "level_bd": gdjs.levelsCode.GDlevel_95bdObjects1});
gdjs.levelsCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10419756);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "sound\\reject.mp3", 100, false, 100, 1);
}}

}


};gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.levelsCode.GDplayerObjects1});
gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595rcdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595gcdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595bcdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595cdObjects1Objects = Hashtable.newFrom({"level_rcd": gdjs.levelsCode.GDlevel_95rcdObjects1, "level_gcd": gdjs.levelsCode.GDlevel_95gcdObjects1, "level_bcd": gdjs.levelsCode.GDlevel_95bcdObjects1, "level_cd": gdjs.levelsCode.GDlevel_95cdObjects1});
gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595rcdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595gcdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595bcdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595cdObjects1Objects = Hashtable.newFrom({"level_rcd": gdjs.levelsCode.GDlevel_95rcdObjects1, "level_gcd": gdjs.levelsCode.GDlevel_95gcdObjects1, "level_bcd": gdjs.levelsCode.GDlevel_95bcdObjects1, "level_cd": gdjs.levelsCode.GDlevel_95cdObjects1});
gdjs.levelsCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9633444);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "sound\\reject.mp3", 100, false, 100, 1);
}}

}


};gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.levelsCode.GDplayerObjects1});
gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595rsdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595gsdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595bsdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595sdObjects1Objects = Hashtable.newFrom({"level_rsd": gdjs.levelsCode.GDlevel_95rsdObjects1, "level_gsd": gdjs.levelsCode.GDlevel_95gsdObjects1, "level_bsd": gdjs.levelsCode.GDlevel_95bsdObjects1, "level_sd": gdjs.levelsCode.GDlevel_95sdObjects1});
gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595rsdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595gsdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595bsdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595sdObjects1Objects = Hashtable.newFrom({"level_rsd": gdjs.levelsCode.GDlevel_95rsdObjects1, "level_gsd": gdjs.levelsCode.GDlevel_95gsdObjects1, "level_bsd": gdjs.levelsCode.GDlevel_95bsdObjects1, "level_sd": gdjs.levelsCode.GDlevel_95sdObjects1});
gdjs.levelsCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17563604);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "sound\\reject.mp3", 100, false, 100, 1);
}}

}


};gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.levelsCode.GDplayerObjects1});
gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595rtdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595gtdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595btdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595tdObjects1Objects = Hashtable.newFrom({"level_rtd": gdjs.levelsCode.GDlevel_95rtdObjects1, "level_gtd": gdjs.levelsCode.GDlevel_95gtdObjects1, "level_btd": gdjs.levelsCode.GDlevel_95btdObjects1, "level_td": gdjs.levelsCode.GDlevel_95tdObjects1});
gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595rtdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595gtdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595btdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595tdObjects1Objects = Hashtable.newFrom({"level_rtd": gdjs.levelsCode.GDlevel_95rtdObjects1, "level_gtd": gdjs.levelsCode.GDlevel_95gtdObjects1, "level_btd": gdjs.levelsCode.GDlevel_95btdObjects1, "level_td": gdjs.levelsCode.GDlevel_95tdObjects1});
gdjs.levelsCode.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16637516);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "sound\\reject.mp3", 100, false, 100, 1);
}}

}


};gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.levelsCode.GDplayerObjects1});
gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595rcpObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595rspObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595rtpObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595rpObjects1Objects = Hashtable.newFrom({"level_rcp": gdjs.levelsCode.GDlevel_95rcpObjects1, "level_rsp": gdjs.levelsCode.GDlevel_95rspObjects1, "level_rtp": gdjs.levelsCode.GDlevel_95rtpObjects1, "level_rp": gdjs.levelsCode.GDlevel_95rpObjects1});
gdjs.levelsCode.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16560236);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "sound\\color.mp3", 100, false, 100, 1);
}}

}


};gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.levelsCode.GDplayerObjects1});
gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595gcpObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595gspObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595gtpObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595gpObjects1Objects = Hashtable.newFrom({"level_gcp": gdjs.levelsCode.GDlevel_95gcpObjects1, "level_gsp": gdjs.levelsCode.GDlevel_95gspObjects1, "level_gtp": gdjs.levelsCode.GDlevel_95gtpObjects1, "level_gp": gdjs.levelsCode.GDlevel_95gpObjects1});
gdjs.levelsCode.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12252292);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "sound\\color.mp3", 100, false, 100, 1);
}}

}


};gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.levelsCode.GDplayerObjects1});
gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595bcpObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595bspObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595btpObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595bpObjects1Objects = Hashtable.newFrom({"level_bcp": gdjs.levelsCode.GDlevel_95bcpObjects1, "level_bsp": gdjs.levelsCode.GDlevel_95bspObjects1, "level_btp": gdjs.levelsCode.GDlevel_95btpObjects1, "level_bp": gdjs.levelsCode.GDlevel_95bpObjects1});
gdjs.levelsCode.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9383828);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "sound\\color.mp3", 100, false, 100, 1);
}}

}


};gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.levelsCode.GDplayerObjects1});
gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595rcpObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595gcpObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595bcpObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595cpObjects1Objects = Hashtable.newFrom({"level_rcp": gdjs.levelsCode.GDlevel_95rcpObjects1, "level_gcp": gdjs.levelsCode.GDlevel_95gcpObjects1, "level_bcp": gdjs.levelsCode.GDlevel_95bcpObjects1, "level_cp": gdjs.levelsCode.GDlevel_95cpObjects1});
gdjs.levelsCode.eventsList9 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11467100);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "sound\\shape.mp3", 100, false, 100, 1);
}}

}


};gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.levelsCode.GDplayerObjects1});
gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595rspObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595gspObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595bspObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595spObjects1Objects = Hashtable.newFrom({"level_rsp": gdjs.levelsCode.GDlevel_95rspObjects1, "level_gsp": gdjs.levelsCode.GDlevel_95gspObjects1, "level_bsp": gdjs.levelsCode.GDlevel_95bspObjects1, "level_sp": gdjs.levelsCode.GDlevel_95spObjects1});
gdjs.levelsCode.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13909460);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "sound\\shape.mp3", 100, false, 100, 1);
}}

}


};gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.levelsCode.GDplayerObjects1});
gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595rtpObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595gtpObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595btpObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595tpObjects1Objects = Hashtable.newFrom({"level_rtp": gdjs.levelsCode.GDlevel_95rtpObjects1, "level_gtp": gdjs.levelsCode.GDlevel_95gtpObjects1, "level_btp": gdjs.levelsCode.GDlevel_95btpObjects1, "level_tp": gdjs.levelsCode.GDlevel_95tpObjects1});
gdjs.levelsCode.eventsList11 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16947924);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "sound\\shape.mp3", 100, false, 100, 1);
}}

}


};gdjs.levelsCode.asyncCallback9947276 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("quit_game"), gdjs.levelsCode.GDquit_95gameObjects7);
{for(var i = 0, len = gdjs.levelsCode.GDquit_95gameObjects7.length ;i < len;++i) {
    gdjs.levelsCode.GDquit_95gameObjects7[i].getBehavior("Tween").addObjectPositionXTween("slide_in", 293, "linear", 500, false);
}
}}
gdjs.levelsCode.eventsList12 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.levelsCode.asyncCallback9947276(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.levelsCode.asyncCallback16199844 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("try_again"), gdjs.levelsCode.GDtry_95againObjects6);
{for(var i = 0, len = gdjs.levelsCode.GDtry_95againObjects6.length ;i < len;++i) {
    gdjs.levelsCode.GDtry_95againObjects6[i].getBehavior("Tween").addObjectPositionXTween("slide_in", 293, "linear", 500, false);
}
}
{ //Subevents
gdjs.levelsCode.eventsList12(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.levelsCode.eventsList13 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.levelsCode.asyncCallback16199844(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.levelsCode.asyncCallback13805404 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("next_level"), gdjs.levelsCode.GDnext_95levelObjects5);
{for(var i = 0, len = gdjs.levelsCode.GDnext_95levelObjects5.length ;i < len;++i) {
    gdjs.levelsCode.GDnext_95levelObjects5[i].getBehavior("Tween").addObjectPositionXTween("slide_in", 293, "linear", 500, false);
}
}
{ //Subevents
gdjs.levelsCode.eventsList13(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.levelsCode.eventsList14 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.levelsCode.asyncCallback13805404(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.levelsCode.asyncCallback10215708 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("level_complete"), gdjs.levelsCode.GDlevel_95completeObjects4);
{for(var i = 0, len = gdjs.levelsCode.GDlevel_95completeObjects4.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95completeObjects4[i].getBehavior("Tween").addObjectPositionXTween("slide_in", 176, "linear", 500, false);
}
}
{ //Subevents
gdjs.levelsCode.eventsList14(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.levelsCode.eventsList15 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.levelsCode.asyncCallback10215708(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.levelsCode.asyncCallback11355244 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("game_time"), gdjs.levelsCode.GDgame_95timeObjects3);
{for(var i = 0, len = gdjs.levelsCode.GDgame_95timeObjects3.length ;i < len;++i) {
    gdjs.levelsCode.GDgame_95timeObjects3[i].getBehavior("Tween").addObjectPositionYTween("slide_in", 326, "linear", 500, false);
}
}
{ //Subevents
gdjs.levelsCode.eventsList15(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.levelsCode.eventsList16 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.levelsCode.asyncCallback11355244(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.levelsCode.asyncCallback10923284 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("quit_game"), gdjs.levelsCode.GDquit_95gameObjects5);
{for(var i = 0, len = gdjs.levelsCode.GDquit_95gameObjects5.length ;i < len;++i) {
    gdjs.levelsCode.GDquit_95gameObjects5[i].getBehavior("Tween").addObjectPositionXTween("slide_in", 293, "linear", 500, false);
}
}}
gdjs.levelsCode.eventsList17 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.levelsCode.asyncCallback10923284(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.levelsCode.asyncCallback16195140 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("try_again"), gdjs.levelsCode.GDtry_95againObjects4);
{for(var i = 0, len = gdjs.levelsCode.GDtry_95againObjects4.length ;i < len;++i) {
    gdjs.levelsCode.GDtry_95againObjects4[i].getBehavior("Tween").addObjectPositionXTween("slide_in", 293, "linear", 500, false);
}
}
{ //Subevents
gdjs.levelsCode.eventsList17(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.levelsCode.eventsList18 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.levelsCode.asyncCallback16195140(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.levelsCode.asyncCallback10922932 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("level_complete"), gdjs.levelsCode.GDlevel_95completeObjects3);
{for(var i = 0, len = gdjs.levelsCode.GDlevel_95completeObjects3.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95completeObjects3[i].getBehavior("Tween").addObjectPositionXTween("slide_in", 176, "linear", 500, false);
}
}
{ //Subevents
gdjs.levelsCode.eventsList18(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.levelsCode.eventsList19 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.levelsCode.asyncCallback10922932(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.levelsCode.asyncCallback10922484 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("game_time"), gdjs.levelsCode.GDgame_95timeObjects2);
{for(var i = 0, len = gdjs.levelsCode.GDgame_95timeObjects2.length ;i < len;++i) {
    gdjs.levelsCode.GDgame_95timeObjects2[i].getBehavior("Tween").addObjectPositionYTween("slide_in", 326, "linear", 500, false);
}
}
{ //Subevents
gdjs.levelsCode.eventsList19(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.levelsCode.eventsList20 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.levelsCode.asyncCallback10922484(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.levelsCode.eventsList21 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) < 13;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(8593660);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("blackscreen"), gdjs.levelsCode.GDblackscreenObjects2);
{for(var i = 0, len = gdjs.levelsCode.GDblackscreenObjects2.length ;i < len;++i) {
    gdjs.levelsCode.GDblackscreenObjects2[i].getBehavior("Tween").addObjectPositionXTween("slide_in", -(50), "linear", 500, false);
}
}
{ //Subevents
gdjs.levelsCode.eventsList16(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 13;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10921964);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("blackscreen"), gdjs.levelsCode.GDblackscreenObjects1);
{for(var i = 0, len = gdjs.levelsCode.GDblackscreenObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDblackscreenObjects1[i].getBehavior("Tween").addObjectPositionXTween("slide_in", -(50), "linear", 500, false);
}
}
{ //Subevents
gdjs.levelsCode.eventsList20(runtimeScene);} //End of subevents
}

}


};gdjs.levelsCode.asyncCallback17596708 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "levels", false);
}}
gdjs.levelsCode.eventsList22 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.levelsCode.asyncCallback17596708(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.levelsCode.asyncCallback10925060 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "levels", false);
}}
gdjs.levelsCode.eventsList23 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.levelsCode.asyncCallback10925060(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.levelsCode.asyncCallback10926540 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "main", false);
}}
gdjs.levelsCode.eventsList24 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.levelsCode.asyncCallback10926540(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.levelsCode.asyncCallback19579100 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "levels", false);
}}
gdjs.levelsCode.eventsList25 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.levelsCode.asyncCallback19579100(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.levelsCode.asyncCallback21176820 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.levelsCode.GDtransitionObjects2);
{for(var i = 0, len = gdjs.levelsCode.GDtransitionObjects2.length ;i < len;++i) {
    gdjs.levelsCode.GDtransitionObjects2[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.5, "Circular", "Forward", 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.levelsCode.eventsList25(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.levelsCode.eventsList26 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.levelsCode.asyncCallback21176820(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.levelsCode.asyncCallback19008340 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "main", false);
}}
gdjs.levelsCode.eventsList27 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.levelsCode.asyncCallback19008340(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.levelsCode.asyncCallback21008900 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.levelsCode.GDtransitionObjects2);
{for(var i = 0, len = gdjs.levelsCode.GDtransitionObjects2.length ;i < len;++i) {
    gdjs.levelsCode.GDtransitionObjects2[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.5, "Circular", "Forward", 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.levelsCode.eventsList27(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.levelsCode.eventsList28 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.levelsCode.asyncCallback21008900(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.levelsCode.eventsList29 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.levelsCode.GDtransitionObjects1);
{for(var i = 0, len = gdjs.levelsCode.GDtransitionObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDtransitionObjects1[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.5, "Flash", "Backward", 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(0);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "game_timer");
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("level_bcd"), gdjs.levelsCode.GDlevel_95bcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bcp"), gdjs.levelsCode.GDlevel_95bcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bd"), gdjs.levelsCode.GDlevel_95bdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bp"), gdjs.levelsCode.GDlevel_95bpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bsd"), gdjs.levelsCode.GDlevel_95bsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bsp"), gdjs.levelsCode.GDlevel_95bspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_btd"), gdjs.levelsCode.GDlevel_95btdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_btp"), gdjs.levelsCode.GDlevel_95btpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_cd"), gdjs.levelsCode.GDlevel_95cdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_cp"), gdjs.levelsCode.GDlevel_95cpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gcd"), gdjs.levelsCode.GDlevel_95gcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gcp"), gdjs.levelsCode.GDlevel_95gcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gd"), gdjs.levelsCode.GDlevel_95gdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gp"), gdjs.levelsCode.GDlevel_95gpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gsd"), gdjs.levelsCode.GDlevel_95gsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gsp"), gdjs.levelsCode.GDlevel_95gspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gtd"), gdjs.levelsCode.GDlevel_95gtdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gtp"), gdjs.levelsCode.GDlevel_95gtpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_map"), gdjs.levelsCode.GDlevel_95mapObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rcd"), gdjs.levelsCode.GDlevel_95rcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rcp"), gdjs.levelsCode.GDlevel_95rcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rd"), gdjs.levelsCode.GDlevel_95rdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rp"), gdjs.levelsCode.GDlevel_95rpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rsd"), gdjs.levelsCode.GDlevel_95rsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rsp"), gdjs.levelsCode.GDlevel_95rspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rtd"), gdjs.levelsCode.GDlevel_95rtdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rtp"), gdjs.levelsCode.GDlevel_95rtpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_sd"), gdjs.levelsCode.GDlevel_95sdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_sp"), gdjs.levelsCode.GDlevel_95spObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_star"), gdjs.levelsCode.GDlevel_95starObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_td"), gdjs.levelsCode.GDlevel_95tdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_tp"), gdjs.levelsCode.GDlevel_95tpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_wall"), gdjs.levelsCode.GDlevel_95wallObjects1);
{for(var i = 0, len = gdjs.levelsCode.GDlevel_95rcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rcdObjects1[i].setPosition((( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getX()),(( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getY()));
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gcdObjects1[i].setPosition((( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getX()),(( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getY()));
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bcdObjects1[i].setPosition((( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getX()),(( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getY()));
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rsdObjects1[i].setPosition((( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getX()),(( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getY()));
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gsdObjects1[i].setPosition((( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getX()),(( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getY()));
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bsdObjects1[i].setPosition((( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getX()),(( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getY()));
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rtdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rtdObjects1[i].setPosition((( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getX()),(( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getY()));
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gtdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gtdObjects1[i].setPosition((( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getX()),(( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getY()));
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95btdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95btdObjects1[i].setPosition((( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getX()),(( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getY()));
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rdObjects1[i].setPosition((( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getX()),(( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getY()));
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gdObjects1[i].setPosition((( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getX()),(( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getY()));
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bdObjects1[i].setPosition((( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getX()),(( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getY()));
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rcpObjects1[i].setPosition((( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getX()),(( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getY()));
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gcpObjects1[i].setPosition((( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getX()),(( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getY()));
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bcpObjects1[i].setPosition((( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getX()),(( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getY()));
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rspObjects1[i].setPosition((( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getX()),(( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getY()));
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gspObjects1[i].setPosition((( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getX()),(( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getY()));
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bspObjects1[i].setPosition((( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getX()),(( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getY()));
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rtpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rtpObjects1[i].setPosition((( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getX()),(( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getY()));
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gtpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gtpObjects1[i].setPosition((( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getX()),(( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getY()));
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95btpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95btpObjects1[i].setPosition((( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getX()),(( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getY()));
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rpObjects1[i].setPosition((( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getX()),(( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getY()));
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gpObjects1[i].setPosition((( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getX()),(( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getY()));
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bpObjects1[i].setPosition((( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getX()),(( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getY()));
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95cpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95cpObjects1[i].setPosition((( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getX()),(( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getY()));
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95spObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95spObjects1[i].setPosition((( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getX()),(( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getY()));
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95tpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95tpObjects1[i].setPosition((( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getX()),(( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getY()));
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95cdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95cdObjects1[i].setPosition((( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getX()),(( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getY()));
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95sdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95sdObjects1[i].setPosition((( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getX()),(( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getY()));
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95tdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95tdObjects1[i].setPosition((( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getX()),(( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getY()));
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95starObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95starObjects1[i].setPosition((( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getX()),(( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getY()));
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95wallObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95wallObjects1[i].setPosition((( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getX()),(( gdjs.levelsCode.GDlevel_95mapObjects1.length === 0 ) ? 0 :gdjs.levelsCode.GDlevel_95mapObjects1[0].getY()));
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("game_time"), gdjs.levelsCode.GDgame_95timeObjects1);
{for(var i = 0, len = gdjs.levelsCode.GDgame_95timeObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDgame_95timeObjects1[i].setString("Your Time: " + gdjs.evtsExt__TimeFormatter__SecondsToHHMMSS.func(runtimeScene, gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSeconds(runtimeScene, "game_timer"), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
}}

}


{



}


{



}


{



}


{



}


{



}


{



}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10871092);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 1;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("level_bcd"), gdjs.levelsCode.GDlevel_95bcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bcp"), gdjs.levelsCode.GDlevel_95bcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bd"), gdjs.levelsCode.GDlevel_95bdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bp"), gdjs.levelsCode.GDlevel_95bpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bsd"), gdjs.levelsCode.GDlevel_95bsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bsp"), gdjs.levelsCode.GDlevel_95bspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_btd"), gdjs.levelsCode.GDlevel_95btdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_btp"), gdjs.levelsCode.GDlevel_95btpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_cd"), gdjs.levelsCode.GDlevel_95cdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_cp"), gdjs.levelsCode.GDlevel_95cpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gcd"), gdjs.levelsCode.GDlevel_95gcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gcp"), gdjs.levelsCode.GDlevel_95gcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gd"), gdjs.levelsCode.GDlevel_95gdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gp"), gdjs.levelsCode.GDlevel_95gpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gsd"), gdjs.levelsCode.GDlevel_95gsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gsp"), gdjs.levelsCode.GDlevel_95gspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gtd"), gdjs.levelsCode.GDlevel_95gtdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gtp"), gdjs.levelsCode.GDlevel_95gtpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_map"), gdjs.levelsCode.GDlevel_95mapObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rcd"), gdjs.levelsCode.GDlevel_95rcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rcp"), gdjs.levelsCode.GDlevel_95rcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rd"), gdjs.levelsCode.GDlevel_95rdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rp"), gdjs.levelsCode.GDlevel_95rpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rsd"), gdjs.levelsCode.GDlevel_95rsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rsp"), gdjs.levelsCode.GDlevel_95rspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rtd"), gdjs.levelsCode.GDlevel_95rtdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rtp"), gdjs.levelsCode.GDlevel_95rtpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_sd"), gdjs.levelsCode.GDlevel_95sdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_sp"), gdjs.levelsCode.GDlevel_95spObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_star"), gdjs.levelsCode.GDlevel_95starObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_td"), gdjs.levelsCode.GDlevel_95tdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_tp"), gdjs.levelsCode.GDlevel_95tpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_wall"), gdjs.levelsCode.GDlevel_95wallObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.levelsCode.GDlevel_95rcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rcdObjects1[i].setTilemapJsonFile("levels\\level1.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gcdObjects1[i].setTilemapJsonFile("levels\\level1.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bcdObjects1[i].setTilemapJsonFile("levels\\level1.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rsdObjects1[i].setTilemapJsonFile("levels\\level1.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gsdObjects1[i].setTilemapJsonFile("levels\\level1.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bsdObjects1[i].setTilemapJsonFile("levels\\level1.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rtdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rtdObjects1[i].setTilemapJsonFile("levels\\level1.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gtdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gtdObjects1[i].setTilemapJsonFile("levels\\level1.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95btdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95btdObjects1[i].setTilemapJsonFile("levels\\level1.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rdObjects1[i].setTilemapJsonFile("levels\\level1.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gdObjects1[i].setTilemapJsonFile("levels\\level1.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bdObjects1[i].setTilemapJsonFile("levels\\level1.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rcpObjects1[i].setTilemapJsonFile("levels\\level1.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gcpObjects1[i].setTilemapJsonFile("levels\\level1.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bcpObjects1[i].setTilemapJsonFile("levels\\level1.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rspObjects1[i].setTilemapJsonFile("levels\\level1.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gspObjects1[i].setTilemapJsonFile("levels\\level1.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bspObjects1[i].setTilemapJsonFile("levels\\level1.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rtpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rtpObjects1[i].setTilemapJsonFile("levels\\level1.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gtpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gtpObjects1[i].setTilemapJsonFile("levels\\level1.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95btpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95btpObjects1[i].setTilemapJsonFile("levels\\level1.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rpObjects1[i].setTilemapJsonFile("levels\\level1.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gpObjects1[i].setTilemapJsonFile("levels\\level1.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bpObjects1[i].setTilemapJsonFile("levels\\level1.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95cpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95cpObjects1[i].setTilemapJsonFile("levels\\level1.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95spObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95spObjects1[i].setTilemapJsonFile("levels\\level1.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95tpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95tpObjects1[i].setTilemapJsonFile("levels\\level1.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95cdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95cdObjects1[i].setTilemapJsonFile("levels\\level1.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95sdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95sdObjects1[i].setTilemapJsonFile("levels\\level1.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95tdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95tdObjects1[i].setTilemapJsonFile("levels\\level1.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95starObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95starObjects1[i].setTilemapJsonFile("levels\\level1.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95wallObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95wallObjects1[i].setTilemapJsonFile("levels\\level1.json");
}
}{for(var i = 0, len = gdjs.levelsCode.GDlevel_95mapObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95mapObjects1[i].setTilemapJsonFile("levels\\level1.json");
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].setPosition(293,415);
}
}{runtimeScene.getGame().getVariables().get("time_limit").setNumber(30);
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10876220);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 2;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("level_bcd"), gdjs.levelsCode.GDlevel_95bcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bcp"), gdjs.levelsCode.GDlevel_95bcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bd"), gdjs.levelsCode.GDlevel_95bdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bp"), gdjs.levelsCode.GDlevel_95bpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bsd"), gdjs.levelsCode.GDlevel_95bsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bsp"), gdjs.levelsCode.GDlevel_95bspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_btd"), gdjs.levelsCode.GDlevel_95btdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_btp"), gdjs.levelsCode.GDlevel_95btpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_cd"), gdjs.levelsCode.GDlevel_95cdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_cp"), gdjs.levelsCode.GDlevel_95cpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gcd"), gdjs.levelsCode.GDlevel_95gcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gcp"), gdjs.levelsCode.GDlevel_95gcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gd"), gdjs.levelsCode.GDlevel_95gdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gp"), gdjs.levelsCode.GDlevel_95gpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gsd"), gdjs.levelsCode.GDlevel_95gsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gsp"), gdjs.levelsCode.GDlevel_95gspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gtd"), gdjs.levelsCode.GDlevel_95gtdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gtp"), gdjs.levelsCode.GDlevel_95gtpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_map"), gdjs.levelsCode.GDlevel_95mapObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rcd"), gdjs.levelsCode.GDlevel_95rcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rcp"), gdjs.levelsCode.GDlevel_95rcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rd"), gdjs.levelsCode.GDlevel_95rdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rp"), gdjs.levelsCode.GDlevel_95rpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rsd"), gdjs.levelsCode.GDlevel_95rsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rsp"), gdjs.levelsCode.GDlevel_95rspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rtd"), gdjs.levelsCode.GDlevel_95rtdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rtp"), gdjs.levelsCode.GDlevel_95rtpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_sd"), gdjs.levelsCode.GDlevel_95sdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_sp"), gdjs.levelsCode.GDlevel_95spObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_star"), gdjs.levelsCode.GDlevel_95starObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_td"), gdjs.levelsCode.GDlevel_95tdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_tp"), gdjs.levelsCode.GDlevel_95tpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_wall"), gdjs.levelsCode.GDlevel_95wallObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.levelsCode.GDlevel_95rcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rcdObjects1[i].setTilemapJsonFile("levels\\level2.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gcdObjects1[i].setTilemapJsonFile("levels\\level2.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bcdObjects1[i].setTilemapJsonFile("levels\\level2.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rsdObjects1[i].setTilemapJsonFile("levels\\level2.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gsdObjects1[i].setTilemapJsonFile("levels\\level2.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bsdObjects1[i].setTilemapJsonFile("levels\\level2.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rtdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rtdObjects1[i].setTilemapJsonFile("levels\\level2.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gtdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gtdObjects1[i].setTilemapJsonFile("levels\\level2.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95btdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95btdObjects1[i].setTilemapJsonFile("levels\\level2.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rdObjects1[i].setTilemapJsonFile("levels\\level2.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gdObjects1[i].setTilemapJsonFile("levels\\level2.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bdObjects1[i].setTilemapJsonFile("levels\\level2.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rcpObjects1[i].setTilemapJsonFile("levels\\level2.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gcpObjects1[i].setTilemapJsonFile("levels\\level2.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bcpObjects1[i].setTilemapJsonFile("levels\\level2.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rspObjects1[i].setTilemapJsonFile("levels\\level2.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gspObjects1[i].setTilemapJsonFile("levels\\level2.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bspObjects1[i].setTilemapJsonFile("levels\\level2.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rtpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rtpObjects1[i].setTilemapJsonFile("levels\\level2.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gtpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gtpObjects1[i].setTilemapJsonFile("levels\\level2.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95btpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95btpObjects1[i].setTilemapJsonFile("levels\\level2.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rpObjects1[i].setTilemapJsonFile("levels\\level2.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gpObjects1[i].setTilemapJsonFile("levels\\level2.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bpObjects1[i].setTilemapJsonFile("levels\\level2.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95cpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95cpObjects1[i].setTilemapJsonFile("levels\\level2.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95spObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95spObjects1[i].setTilemapJsonFile("levels\\level2.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95tpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95tpObjects1[i].setTilemapJsonFile("levels\\level2.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95cdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95cdObjects1[i].setTilemapJsonFile("levels\\level2.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95sdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95sdObjects1[i].setTilemapJsonFile("levels\\level2.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95tdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95tdObjects1[i].setTilemapJsonFile("levels\\level2.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95starObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95starObjects1[i].setTilemapJsonFile("levels\\level2.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95wallObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95wallObjects1[i].setTilemapJsonFile("levels\\level2.json");
}
}{for(var i = 0, len = gdjs.levelsCode.GDlevel_95mapObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95mapObjects1[i].setTilemapJsonFile("levels\\level2.json");
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].setPosition(239,415);
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].returnVariable(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(1)).setNumber(1);
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].returnVariable(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(0)).setNumber(3);
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}{runtimeScene.getGame().getVariables().get("time_limit").setNumber(30);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10889380);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 3;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("level_bcd"), gdjs.levelsCode.GDlevel_95bcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bcp"), gdjs.levelsCode.GDlevel_95bcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bd"), gdjs.levelsCode.GDlevel_95bdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bp"), gdjs.levelsCode.GDlevel_95bpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bsd"), gdjs.levelsCode.GDlevel_95bsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bsp"), gdjs.levelsCode.GDlevel_95bspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_btd"), gdjs.levelsCode.GDlevel_95btdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_btp"), gdjs.levelsCode.GDlevel_95btpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_cd"), gdjs.levelsCode.GDlevel_95cdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_cp"), gdjs.levelsCode.GDlevel_95cpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gcd"), gdjs.levelsCode.GDlevel_95gcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gcp"), gdjs.levelsCode.GDlevel_95gcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gd"), gdjs.levelsCode.GDlevel_95gdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gp"), gdjs.levelsCode.GDlevel_95gpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gsd"), gdjs.levelsCode.GDlevel_95gsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gsp"), gdjs.levelsCode.GDlevel_95gspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gtd"), gdjs.levelsCode.GDlevel_95gtdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gtp"), gdjs.levelsCode.GDlevel_95gtpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_map"), gdjs.levelsCode.GDlevel_95mapObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rcd"), gdjs.levelsCode.GDlevel_95rcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rcp"), gdjs.levelsCode.GDlevel_95rcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rd"), gdjs.levelsCode.GDlevel_95rdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rp"), gdjs.levelsCode.GDlevel_95rpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rsd"), gdjs.levelsCode.GDlevel_95rsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rsp"), gdjs.levelsCode.GDlevel_95rspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rtd"), gdjs.levelsCode.GDlevel_95rtdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rtp"), gdjs.levelsCode.GDlevel_95rtpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_sd"), gdjs.levelsCode.GDlevel_95sdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_sp"), gdjs.levelsCode.GDlevel_95spObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_star"), gdjs.levelsCode.GDlevel_95starObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_td"), gdjs.levelsCode.GDlevel_95tdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_tp"), gdjs.levelsCode.GDlevel_95tpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_wall"), gdjs.levelsCode.GDlevel_95wallObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.levelsCode.GDlevel_95rcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rcdObjects1[i].setTilemapJsonFile("levels\\level3.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gcdObjects1[i].setTilemapJsonFile("levels\\level3.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bcdObjects1[i].setTilemapJsonFile("levels\\level3.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rsdObjects1[i].setTilemapJsonFile("levels\\level3.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gsdObjects1[i].setTilemapJsonFile("levels\\level3.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bsdObjects1[i].setTilemapJsonFile("levels\\level3.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rtdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rtdObjects1[i].setTilemapJsonFile("levels\\level3.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gtdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gtdObjects1[i].setTilemapJsonFile("levels\\level3.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95btdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95btdObjects1[i].setTilemapJsonFile("levels\\level3.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rdObjects1[i].setTilemapJsonFile("levels\\level3.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gdObjects1[i].setTilemapJsonFile("levels\\level3.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bdObjects1[i].setTilemapJsonFile("levels\\level3.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rcpObjects1[i].setTilemapJsonFile("levels\\level3.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gcpObjects1[i].setTilemapJsonFile("levels\\level3.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bcpObjects1[i].setTilemapJsonFile("levels\\level3.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rspObjects1[i].setTilemapJsonFile("levels\\level3.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gspObjects1[i].setTilemapJsonFile("levels\\level3.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bspObjects1[i].setTilemapJsonFile("levels\\level3.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rtpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rtpObjects1[i].setTilemapJsonFile("levels\\level3.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gtpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gtpObjects1[i].setTilemapJsonFile("levels\\level3.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95btpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95btpObjects1[i].setTilemapJsonFile("levels\\level3.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rpObjects1[i].setTilemapJsonFile("levels\\level3.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gpObjects1[i].setTilemapJsonFile("levels\\level3.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bpObjects1[i].setTilemapJsonFile("levels\\level3.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95cpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95cpObjects1[i].setTilemapJsonFile("levels\\level3.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95spObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95spObjects1[i].setTilemapJsonFile("levels\\level3.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95tpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95tpObjects1[i].setTilemapJsonFile("levels\\level3.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95cdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95cdObjects1[i].setTilemapJsonFile("levels\\level3.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95sdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95sdObjects1[i].setTilemapJsonFile("levels\\level3.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95tdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95tdObjects1[i].setTilemapJsonFile("levels\\level3.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95starObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95starObjects1[i].setTilemapJsonFile("levels\\level3.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95wallObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95wallObjects1[i].setTilemapJsonFile("levels\\level3.json");
}
}{for(var i = 0, len = gdjs.levelsCode.GDlevel_95mapObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95mapObjects1[i].setTilemapJsonFile("levels\\level3.json");
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].setPosition(347,415);
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].returnVariable(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(1)).setNumber(1);
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].returnVariable(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}{runtimeScene.getGame().getVariables().get("time_limit").setNumber(30);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10891532);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 4;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("level_bcd"), gdjs.levelsCode.GDlevel_95bcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bcp"), gdjs.levelsCode.GDlevel_95bcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bd"), gdjs.levelsCode.GDlevel_95bdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bp"), gdjs.levelsCode.GDlevel_95bpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bsd"), gdjs.levelsCode.GDlevel_95bsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bsp"), gdjs.levelsCode.GDlevel_95bspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_btd"), gdjs.levelsCode.GDlevel_95btdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_btp"), gdjs.levelsCode.GDlevel_95btpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_cd"), gdjs.levelsCode.GDlevel_95cdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_cp"), gdjs.levelsCode.GDlevel_95cpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gcd"), gdjs.levelsCode.GDlevel_95gcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gcp"), gdjs.levelsCode.GDlevel_95gcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gd"), gdjs.levelsCode.GDlevel_95gdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gp"), gdjs.levelsCode.GDlevel_95gpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gsd"), gdjs.levelsCode.GDlevel_95gsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gsp"), gdjs.levelsCode.GDlevel_95gspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gtd"), gdjs.levelsCode.GDlevel_95gtdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gtp"), gdjs.levelsCode.GDlevel_95gtpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_map"), gdjs.levelsCode.GDlevel_95mapObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rcd"), gdjs.levelsCode.GDlevel_95rcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rcp"), gdjs.levelsCode.GDlevel_95rcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rd"), gdjs.levelsCode.GDlevel_95rdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rp"), gdjs.levelsCode.GDlevel_95rpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rsd"), gdjs.levelsCode.GDlevel_95rsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rsp"), gdjs.levelsCode.GDlevel_95rspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rtd"), gdjs.levelsCode.GDlevel_95rtdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rtp"), gdjs.levelsCode.GDlevel_95rtpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_sd"), gdjs.levelsCode.GDlevel_95sdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_sp"), gdjs.levelsCode.GDlevel_95spObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_star"), gdjs.levelsCode.GDlevel_95starObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_td"), gdjs.levelsCode.GDlevel_95tdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_tp"), gdjs.levelsCode.GDlevel_95tpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_wall"), gdjs.levelsCode.GDlevel_95wallObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.levelsCode.GDlevel_95rcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rcdObjects1[i].setTilemapJsonFile("levels\\level4.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gcdObjects1[i].setTilemapJsonFile("levels\\level4.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bcdObjects1[i].setTilemapJsonFile("levels\\level4.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rsdObjects1[i].setTilemapJsonFile("levels\\level4.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gsdObjects1[i].setTilemapJsonFile("levels\\level4.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bsdObjects1[i].setTilemapJsonFile("levels\\level4.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rtdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rtdObjects1[i].setTilemapJsonFile("levels\\level4.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gtdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gtdObjects1[i].setTilemapJsonFile("levels\\level4.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95btdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95btdObjects1[i].setTilemapJsonFile("levels\\level4.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rdObjects1[i].setTilemapJsonFile("levels\\level4.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gdObjects1[i].setTilemapJsonFile("levels\\level4.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bdObjects1[i].setTilemapJsonFile("levels\\level4.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rcpObjects1[i].setTilemapJsonFile("levels\\level4.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gcpObjects1[i].setTilemapJsonFile("levels\\level4.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bcpObjects1[i].setTilemapJsonFile("levels\\level4.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rspObjects1[i].setTilemapJsonFile("levels\\level4.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gspObjects1[i].setTilemapJsonFile("levels\\level4.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bspObjects1[i].setTilemapJsonFile("levels\\level4.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rtpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rtpObjects1[i].setTilemapJsonFile("levels\\level4.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gtpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gtpObjects1[i].setTilemapJsonFile("levels\\level4.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95btpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95btpObjects1[i].setTilemapJsonFile("levels\\level4.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rpObjects1[i].setTilemapJsonFile("levels\\level4.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gpObjects1[i].setTilemapJsonFile("levels\\level4.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bpObjects1[i].setTilemapJsonFile("levels\\level4.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95cpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95cpObjects1[i].setTilemapJsonFile("levels\\level4.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95spObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95spObjects1[i].setTilemapJsonFile("levels\\level4.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95tpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95tpObjects1[i].setTilemapJsonFile("levels\\level4.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95cdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95cdObjects1[i].setTilemapJsonFile("levels\\level4.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95sdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95sdObjects1[i].setTilemapJsonFile("levels\\level4.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95tdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95tdObjects1[i].setTilemapJsonFile("levels\\level4.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95starObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95starObjects1[i].setTilemapJsonFile("levels\\level4.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95wallObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95wallObjects1[i].setTilemapJsonFile("levels\\level4.json");
}
}{for(var i = 0, len = gdjs.levelsCode.GDlevel_95mapObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95mapObjects1[i].setTilemapJsonFile("levels\\level4.json");
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].setPosition(347,415);
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].returnVariable(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(1)).setNumber(3);
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].returnVariable(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(0)).setNumber(2);
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}{runtimeScene.getGame().getVariables().get("time_limit").setNumber(30);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10893636);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 5;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("level_bcd"), gdjs.levelsCode.GDlevel_95bcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bcp"), gdjs.levelsCode.GDlevel_95bcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bd"), gdjs.levelsCode.GDlevel_95bdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bp"), gdjs.levelsCode.GDlevel_95bpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bsd"), gdjs.levelsCode.GDlevel_95bsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bsp"), gdjs.levelsCode.GDlevel_95bspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_btd"), gdjs.levelsCode.GDlevel_95btdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_btp"), gdjs.levelsCode.GDlevel_95btpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_cd"), gdjs.levelsCode.GDlevel_95cdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_cp"), gdjs.levelsCode.GDlevel_95cpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gcd"), gdjs.levelsCode.GDlevel_95gcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gcp"), gdjs.levelsCode.GDlevel_95gcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gd"), gdjs.levelsCode.GDlevel_95gdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gp"), gdjs.levelsCode.GDlevel_95gpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gsd"), gdjs.levelsCode.GDlevel_95gsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gsp"), gdjs.levelsCode.GDlevel_95gspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gtd"), gdjs.levelsCode.GDlevel_95gtdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gtp"), gdjs.levelsCode.GDlevel_95gtpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_map"), gdjs.levelsCode.GDlevel_95mapObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rcd"), gdjs.levelsCode.GDlevel_95rcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rcp"), gdjs.levelsCode.GDlevel_95rcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rd"), gdjs.levelsCode.GDlevel_95rdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rp"), gdjs.levelsCode.GDlevel_95rpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rsd"), gdjs.levelsCode.GDlevel_95rsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rsp"), gdjs.levelsCode.GDlevel_95rspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rtd"), gdjs.levelsCode.GDlevel_95rtdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rtp"), gdjs.levelsCode.GDlevel_95rtpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_sd"), gdjs.levelsCode.GDlevel_95sdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_sp"), gdjs.levelsCode.GDlevel_95spObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_star"), gdjs.levelsCode.GDlevel_95starObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_td"), gdjs.levelsCode.GDlevel_95tdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_tp"), gdjs.levelsCode.GDlevel_95tpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_wall"), gdjs.levelsCode.GDlevel_95wallObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.levelsCode.GDlevel_95rcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rcdObjects1[i].setTilemapJsonFile("levels\\level5.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gcdObjects1[i].setTilemapJsonFile("levels\\level5.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bcdObjects1[i].setTilemapJsonFile("levels\\level5.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rsdObjects1[i].setTilemapJsonFile("levels\\level5.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gsdObjects1[i].setTilemapJsonFile("levels\\level5.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bsdObjects1[i].setTilemapJsonFile("levels\\level5.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rtdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rtdObjects1[i].setTilemapJsonFile("levels\\level5.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gtdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gtdObjects1[i].setTilemapJsonFile("levels\\level5.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95btdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95btdObjects1[i].setTilemapJsonFile("levels\\level5.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rdObjects1[i].setTilemapJsonFile("levels\\level5.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gdObjects1[i].setTilemapJsonFile("levels\\level5.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bdObjects1[i].setTilemapJsonFile("levels\\level5.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rcpObjects1[i].setTilemapJsonFile("levels\\level5.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gcpObjects1[i].setTilemapJsonFile("levels\\level5.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bcpObjects1[i].setTilemapJsonFile("levels\\level5.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rspObjects1[i].setTilemapJsonFile("levels\\level5.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gspObjects1[i].setTilemapJsonFile("levels\\level5.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bspObjects1[i].setTilemapJsonFile("levels\\level5.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rtpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rtpObjects1[i].setTilemapJsonFile("levels\\level5.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gtpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gtpObjects1[i].setTilemapJsonFile("levels\\level5.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95btpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95btpObjects1[i].setTilemapJsonFile("levels\\level5.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rpObjects1[i].setTilemapJsonFile("levels\\level5.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gpObjects1[i].setTilemapJsonFile("levels\\level5.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bpObjects1[i].setTilemapJsonFile("levels\\level5.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95cpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95cpObjects1[i].setTilemapJsonFile("levels\\level5.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95spObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95spObjects1[i].setTilemapJsonFile("levels\\level5.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95tpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95tpObjects1[i].setTilemapJsonFile("levels\\level5.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95cdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95cdObjects1[i].setTilemapJsonFile("levels\\level5.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95sdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95sdObjects1[i].setTilemapJsonFile("levels\\level5.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95tdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95tdObjects1[i].setTilemapJsonFile("levels\\level5.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95starObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95starObjects1[i].setTilemapJsonFile("levels\\level5.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95wallObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95wallObjects1[i].setTilemapJsonFile("levels\\level5.json");
}
}{for(var i = 0, len = gdjs.levelsCode.GDlevel_95mapObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95mapObjects1[i].setTilemapJsonFile("levels\\level5.json");
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].setPosition(346,311);
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].returnVariable(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(1)).setNumber(3);
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].returnVariable(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}{runtimeScene.getGame().getVariables().get("time_limit").setNumber(30);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10895700);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 6;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("level_bcd"), gdjs.levelsCode.GDlevel_95bcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bcp"), gdjs.levelsCode.GDlevel_95bcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bd"), gdjs.levelsCode.GDlevel_95bdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bp"), gdjs.levelsCode.GDlevel_95bpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bsd"), gdjs.levelsCode.GDlevel_95bsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bsp"), gdjs.levelsCode.GDlevel_95bspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_btd"), gdjs.levelsCode.GDlevel_95btdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_btp"), gdjs.levelsCode.GDlevel_95btpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_cd"), gdjs.levelsCode.GDlevel_95cdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_cp"), gdjs.levelsCode.GDlevel_95cpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gcd"), gdjs.levelsCode.GDlevel_95gcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gcp"), gdjs.levelsCode.GDlevel_95gcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gd"), gdjs.levelsCode.GDlevel_95gdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gp"), gdjs.levelsCode.GDlevel_95gpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gsd"), gdjs.levelsCode.GDlevel_95gsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gsp"), gdjs.levelsCode.GDlevel_95gspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gtd"), gdjs.levelsCode.GDlevel_95gtdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gtp"), gdjs.levelsCode.GDlevel_95gtpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_map"), gdjs.levelsCode.GDlevel_95mapObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rcd"), gdjs.levelsCode.GDlevel_95rcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rcp"), gdjs.levelsCode.GDlevel_95rcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rd"), gdjs.levelsCode.GDlevel_95rdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rp"), gdjs.levelsCode.GDlevel_95rpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rsd"), gdjs.levelsCode.GDlevel_95rsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rsp"), gdjs.levelsCode.GDlevel_95rspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rtd"), gdjs.levelsCode.GDlevel_95rtdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rtp"), gdjs.levelsCode.GDlevel_95rtpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_sd"), gdjs.levelsCode.GDlevel_95sdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_sp"), gdjs.levelsCode.GDlevel_95spObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_star"), gdjs.levelsCode.GDlevel_95starObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_td"), gdjs.levelsCode.GDlevel_95tdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_tp"), gdjs.levelsCode.GDlevel_95tpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_wall"), gdjs.levelsCode.GDlevel_95wallObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.levelsCode.GDlevel_95rcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rcdObjects1[i].setTilemapJsonFile("levels\\level6.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gcdObjects1[i].setTilemapJsonFile("levels\\level6.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bcdObjects1[i].setTilemapJsonFile("levels\\level6.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rsdObjects1[i].setTilemapJsonFile("levels\\level6.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gsdObjects1[i].setTilemapJsonFile("levels\\level6.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bsdObjects1[i].setTilemapJsonFile("levels\\level6.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rtdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rtdObjects1[i].setTilemapJsonFile("levels\\level6.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gtdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gtdObjects1[i].setTilemapJsonFile("levels\\level6.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95btdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95btdObjects1[i].setTilemapJsonFile("levels\\level6.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rdObjects1[i].setTilemapJsonFile("levels\\level6.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gdObjects1[i].setTilemapJsonFile("levels\\level6.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bdObjects1[i].setTilemapJsonFile("levels\\level6.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rcpObjects1[i].setTilemapJsonFile("levels\\level6.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gcpObjects1[i].setTilemapJsonFile("levels\\level6.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bcpObjects1[i].setTilemapJsonFile("levels\\level6.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rspObjects1[i].setTilemapJsonFile("levels\\level6.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gspObjects1[i].setTilemapJsonFile("levels\\level6.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bspObjects1[i].setTilemapJsonFile("levels\\level6.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rtpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rtpObjects1[i].setTilemapJsonFile("levels\\level6.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gtpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gtpObjects1[i].setTilemapJsonFile("levels\\level6.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95btpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95btpObjects1[i].setTilemapJsonFile("levels\\level6.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rpObjects1[i].setTilemapJsonFile("levels\\level6.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gpObjects1[i].setTilemapJsonFile("levels\\level6.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bpObjects1[i].setTilemapJsonFile("levels\\level6.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95cpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95cpObjects1[i].setTilemapJsonFile("levels\\level6.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95spObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95spObjects1[i].setTilemapJsonFile("levels\\level6.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95tpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95tpObjects1[i].setTilemapJsonFile("levels\\level6.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95cdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95cdObjects1[i].setTilemapJsonFile("levels\\level6.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95sdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95sdObjects1[i].setTilemapJsonFile("levels\\level6.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95tdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95tdObjects1[i].setTilemapJsonFile("levels\\level6.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95starObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95starObjects1[i].setTilemapJsonFile("levels\\level6.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95wallObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95wallObjects1[i].setTilemapJsonFile("levels\\level6.json");
}
}{for(var i = 0, len = gdjs.levelsCode.GDlevel_95mapObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95mapObjects1[i].setTilemapJsonFile("levels\\level6.json");
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].setPosition(725,468);
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].returnVariable(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(1)).setNumber(1);
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].returnVariable(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(0)).setNumber(2);
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}{runtimeScene.getGame().getVariables().get("time_limit").setNumber(30);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10897772);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 7;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("level_bcd"), gdjs.levelsCode.GDlevel_95bcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bcp"), gdjs.levelsCode.GDlevel_95bcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bd"), gdjs.levelsCode.GDlevel_95bdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bp"), gdjs.levelsCode.GDlevel_95bpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bsd"), gdjs.levelsCode.GDlevel_95bsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bsp"), gdjs.levelsCode.GDlevel_95bspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_btd"), gdjs.levelsCode.GDlevel_95btdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_btp"), gdjs.levelsCode.GDlevel_95btpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_cd"), gdjs.levelsCode.GDlevel_95cdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_cp"), gdjs.levelsCode.GDlevel_95cpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gcd"), gdjs.levelsCode.GDlevel_95gcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gcp"), gdjs.levelsCode.GDlevel_95gcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gd"), gdjs.levelsCode.GDlevel_95gdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gp"), gdjs.levelsCode.GDlevel_95gpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gsd"), gdjs.levelsCode.GDlevel_95gsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gsp"), gdjs.levelsCode.GDlevel_95gspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gtd"), gdjs.levelsCode.GDlevel_95gtdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gtp"), gdjs.levelsCode.GDlevel_95gtpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_map"), gdjs.levelsCode.GDlevel_95mapObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rcd"), gdjs.levelsCode.GDlevel_95rcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rcp"), gdjs.levelsCode.GDlevel_95rcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rd"), gdjs.levelsCode.GDlevel_95rdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rp"), gdjs.levelsCode.GDlevel_95rpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rsd"), gdjs.levelsCode.GDlevel_95rsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rsp"), gdjs.levelsCode.GDlevel_95rspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rtd"), gdjs.levelsCode.GDlevel_95rtdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rtp"), gdjs.levelsCode.GDlevel_95rtpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_sd"), gdjs.levelsCode.GDlevel_95sdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_sp"), gdjs.levelsCode.GDlevel_95spObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_star"), gdjs.levelsCode.GDlevel_95starObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_td"), gdjs.levelsCode.GDlevel_95tdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_tp"), gdjs.levelsCode.GDlevel_95tpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_wall"), gdjs.levelsCode.GDlevel_95wallObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.levelsCode.GDlevel_95rcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rcdObjects1[i].setTilemapJsonFile("levels\\level7.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gcdObjects1[i].setTilemapJsonFile("levels\\level7.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bcdObjects1[i].setTilemapJsonFile("levels\\level7.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rsdObjects1[i].setTilemapJsonFile("levels\\level7.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gsdObjects1[i].setTilemapJsonFile("levels\\level7.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bsdObjects1[i].setTilemapJsonFile("levels\\level7.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rtdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rtdObjects1[i].setTilemapJsonFile("levels\\level7.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gtdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gtdObjects1[i].setTilemapJsonFile("levels\\level7.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95btdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95btdObjects1[i].setTilemapJsonFile("levels\\level7.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rdObjects1[i].setTilemapJsonFile("levels\\level7.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gdObjects1[i].setTilemapJsonFile("levels\\level7.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bdObjects1[i].setTilemapJsonFile("levels\\level7.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rcpObjects1[i].setTilemapJsonFile("levels\\level7.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gcpObjects1[i].setTilemapJsonFile("levels\\level7.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bcpObjects1[i].setTilemapJsonFile("levels\\level7.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rspObjects1[i].setTilemapJsonFile("levels\\level7.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gspObjects1[i].setTilemapJsonFile("levels\\level7.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bspObjects1[i].setTilemapJsonFile("levels\\level7.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rtpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rtpObjects1[i].setTilemapJsonFile("levels\\level7.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gtpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gtpObjects1[i].setTilemapJsonFile("levels\\level7.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95btpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95btpObjects1[i].setTilemapJsonFile("levels\\level7.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rpObjects1[i].setTilemapJsonFile("levels\\level7.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gpObjects1[i].setTilemapJsonFile("levels\\level7.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bpObjects1[i].setTilemapJsonFile("levels\\level7.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95cpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95cpObjects1[i].setTilemapJsonFile("levels\\level7.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95spObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95spObjects1[i].setTilemapJsonFile("levels\\level7.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95tpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95tpObjects1[i].setTilemapJsonFile("levels\\level7.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95cdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95cdObjects1[i].setTilemapJsonFile("levels\\level7.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95sdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95sdObjects1[i].setTilemapJsonFile("levels\\level7.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95tdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95tdObjects1[i].setTilemapJsonFile("levels\\level7.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95starObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95starObjects1[i].setTilemapJsonFile("levels\\level7.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95wallObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95wallObjects1[i].setTilemapJsonFile("levels\\level7.json");
}
}{for(var i = 0, len = gdjs.levelsCode.GDlevel_95mapObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95mapObjects1[i].setTilemapJsonFile("levels\\level7.json");
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].setPosition(510,625);
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].returnVariable(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(1)).setNumber(1);
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].returnVariable(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}{runtimeScene.getGame().getVariables().get("time_limit").setNumber(30);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10899876);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 8;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("level_bcd"), gdjs.levelsCode.GDlevel_95bcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bcp"), gdjs.levelsCode.GDlevel_95bcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bd"), gdjs.levelsCode.GDlevel_95bdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bp"), gdjs.levelsCode.GDlevel_95bpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bsd"), gdjs.levelsCode.GDlevel_95bsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bsp"), gdjs.levelsCode.GDlevel_95bspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_btd"), gdjs.levelsCode.GDlevel_95btdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_btp"), gdjs.levelsCode.GDlevel_95btpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_cd"), gdjs.levelsCode.GDlevel_95cdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_cp"), gdjs.levelsCode.GDlevel_95cpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gcd"), gdjs.levelsCode.GDlevel_95gcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gcp"), gdjs.levelsCode.GDlevel_95gcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gd"), gdjs.levelsCode.GDlevel_95gdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gp"), gdjs.levelsCode.GDlevel_95gpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gsd"), gdjs.levelsCode.GDlevel_95gsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gsp"), gdjs.levelsCode.GDlevel_95gspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gtd"), gdjs.levelsCode.GDlevel_95gtdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gtp"), gdjs.levelsCode.GDlevel_95gtpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_map"), gdjs.levelsCode.GDlevel_95mapObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rcd"), gdjs.levelsCode.GDlevel_95rcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rcp"), gdjs.levelsCode.GDlevel_95rcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rd"), gdjs.levelsCode.GDlevel_95rdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rp"), gdjs.levelsCode.GDlevel_95rpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rsd"), gdjs.levelsCode.GDlevel_95rsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rsp"), gdjs.levelsCode.GDlevel_95rspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rtd"), gdjs.levelsCode.GDlevel_95rtdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rtp"), gdjs.levelsCode.GDlevel_95rtpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_sd"), gdjs.levelsCode.GDlevel_95sdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_sp"), gdjs.levelsCode.GDlevel_95spObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_star"), gdjs.levelsCode.GDlevel_95starObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_td"), gdjs.levelsCode.GDlevel_95tdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_tp"), gdjs.levelsCode.GDlevel_95tpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_wall"), gdjs.levelsCode.GDlevel_95wallObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.levelsCode.GDlevel_95rcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rcdObjects1[i].setTilemapJsonFile("levels\\level8.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gcdObjects1[i].setTilemapJsonFile("levels\\level8.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bcdObjects1[i].setTilemapJsonFile("levels\\level8.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rsdObjects1[i].setTilemapJsonFile("levels\\level8.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gsdObjects1[i].setTilemapJsonFile("levels\\level8.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bsdObjects1[i].setTilemapJsonFile("levels\\level8.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rtdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rtdObjects1[i].setTilemapJsonFile("levels\\level8.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gtdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gtdObjects1[i].setTilemapJsonFile("levels\\level8.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95btdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95btdObjects1[i].setTilemapJsonFile("levels\\level8.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rdObjects1[i].setTilemapJsonFile("levels\\level8.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gdObjects1[i].setTilemapJsonFile("levels\\level8.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bdObjects1[i].setTilemapJsonFile("levels\\level8.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rcpObjects1[i].setTilemapJsonFile("levels\\level8.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gcpObjects1[i].setTilemapJsonFile("levels\\level8.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bcpObjects1[i].setTilemapJsonFile("levels\\level8.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rspObjects1[i].setTilemapJsonFile("levels\\level8.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gspObjects1[i].setTilemapJsonFile("levels\\level8.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bspObjects1[i].setTilemapJsonFile("levels\\level8.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rtpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rtpObjects1[i].setTilemapJsonFile("levels\\level8.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gtpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gtpObjects1[i].setTilemapJsonFile("levels\\level8.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95btpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95btpObjects1[i].setTilemapJsonFile("levels\\level8.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rpObjects1[i].setTilemapJsonFile("levels\\level8.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gpObjects1[i].setTilemapJsonFile("levels\\level8.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bpObjects1[i].setTilemapJsonFile("levels\\level8.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95cpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95cpObjects1[i].setTilemapJsonFile("levels\\level8.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95spObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95spObjects1[i].setTilemapJsonFile("levels\\level8.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95tpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95tpObjects1[i].setTilemapJsonFile("levels\\level8.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95cdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95cdObjects1[i].setTilemapJsonFile("levels\\level8.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95sdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95sdObjects1[i].setTilemapJsonFile("levels\\level8.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95tdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95tdObjects1[i].setTilemapJsonFile("levels\\level8.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95starObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95starObjects1[i].setTilemapJsonFile("levels\\level8.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95wallObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95wallObjects1[i].setTilemapJsonFile("levels\\level8.json");
}
}{for(var i = 0, len = gdjs.levelsCode.GDlevel_95mapObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95mapObjects1[i].setTilemapJsonFile("levels\\level8.json");
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].setPosition(781,205);
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].returnVariable(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(1)).setNumber(2);
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].returnVariable(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].returnVariable(gdjs.levelsCode.GDplayerObjects1[i].getVariables().get("time_limit")).setNumber(30);
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].returnVariable(gdjs.levelsCode.GDplayerObjects1[i].getVariables().get("current_time")).setNumber(0);
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}{runtimeScene.getGame().getVariables().get("time_limit").setNumber(30);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10902404);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 9;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("level_bcd"), gdjs.levelsCode.GDlevel_95bcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bcp"), gdjs.levelsCode.GDlevel_95bcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bd"), gdjs.levelsCode.GDlevel_95bdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bp"), gdjs.levelsCode.GDlevel_95bpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bsd"), gdjs.levelsCode.GDlevel_95bsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bsp"), gdjs.levelsCode.GDlevel_95bspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_btd"), gdjs.levelsCode.GDlevel_95btdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_btp"), gdjs.levelsCode.GDlevel_95btpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_cd"), gdjs.levelsCode.GDlevel_95cdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_cp"), gdjs.levelsCode.GDlevel_95cpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gcd"), gdjs.levelsCode.GDlevel_95gcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gcp"), gdjs.levelsCode.GDlevel_95gcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gd"), gdjs.levelsCode.GDlevel_95gdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gp"), gdjs.levelsCode.GDlevel_95gpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gsd"), gdjs.levelsCode.GDlevel_95gsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gsp"), gdjs.levelsCode.GDlevel_95gspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gtd"), gdjs.levelsCode.GDlevel_95gtdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gtp"), gdjs.levelsCode.GDlevel_95gtpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_map"), gdjs.levelsCode.GDlevel_95mapObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rcd"), gdjs.levelsCode.GDlevel_95rcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rcp"), gdjs.levelsCode.GDlevel_95rcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rd"), gdjs.levelsCode.GDlevel_95rdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rp"), gdjs.levelsCode.GDlevel_95rpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rsd"), gdjs.levelsCode.GDlevel_95rsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rsp"), gdjs.levelsCode.GDlevel_95rspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rtd"), gdjs.levelsCode.GDlevel_95rtdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rtp"), gdjs.levelsCode.GDlevel_95rtpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_sd"), gdjs.levelsCode.GDlevel_95sdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_sp"), gdjs.levelsCode.GDlevel_95spObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_star"), gdjs.levelsCode.GDlevel_95starObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_td"), gdjs.levelsCode.GDlevel_95tdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_tp"), gdjs.levelsCode.GDlevel_95tpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_wall"), gdjs.levelsCode.GDlevel_95wallObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.levelsCode.GDlevel_95rcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rcdObjects1[i].setTilemapJsonFile("levels\\level9.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gcdObjects1[i].setTilemapJsonFile("levels\\level9.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bcdObjects1[i].setTilemapJsonFile("levels\\level9.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rsdObjects1[i].setTilemapJsonFile("levels\\level9.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gsdObjects1[i].setTilemapJsonFile("levels\\level9.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bsdObjects1[i].setTilemapJsonFile("levels\\level9.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rtdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rtdObjects1[i].setTilemapJsonFile("levels\\level9.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gtdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gtdObjects1[i].setTilemapJsonFile("levels\\level9.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95btdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95btdObjects1[i].setTilemapJsonFile("levels\\level9.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rdObjects1[i].setTilemapJsonFile("levels\\level9.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gdObjects1[i].setTilemapJsonFile("levels\\level9.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bdObjects1[i].setTilemapJsonFile("levels\\level9.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rcpObjects1[i].setTilemapJsonFile("levels\\level9.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gcpObjects1[i].setTilemapJsonFile("levels\\level9.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bcpObjects1[i].setTilemapJsonFile("levels\\level9.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rspObjects1[i].setTilemapJsonFile("levels\\level9.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gspObjects1[i].setTilemapJsonFile("levels\\level9.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bspObjects1[i].setTilemapJsonFile("levels\\level9.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rtpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rtpObjects1[i].setTilemapJsonFile("levels\\level9.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gtpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gtpObjects1[i].setTilemapJsonFile("levels\\level9.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95btpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95btpObjects1[i].setTilemapJsonFile("levels\\level9.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rpObjects1[i].setTilemapJsonFile("levels\\level9.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gpObjects1[i].setTilemapJsonFile("levels\\level9.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bpObjects1[i].setTilemapJsonFile("levels\\level9.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95cpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95cpObjects1[i].setTilemapJsonFile("levels\\level9.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95spObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95spObjects1[i].setTilemapJsonFile("levels\\level9.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95tpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95tpObjects1[i].setTilemapJsonFile("levels\\level9.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95cdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95cdObjects1[i].setTilemapJsonFile("levels\\level9.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95sdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95sdObjects1[i].setTilemapJsonFile("levels\\level9.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95tdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95tdObjects1[i].setTilemapJsonFile("levels\\level9.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95starObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95starObjects1[i].setTilemapJsonFile("levels\\level9.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95wallObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95wallObjects1[i].setTilemapJsonFile("levels\\level9.json");
}
}{for(var i = 0, len = gdjs.levelsCode.GDlevel_95mapObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95mapObjects1[i].setTilemapJsonFile("levels\\level9.json");
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].setPosition(726,573);
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].returnVariable(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(1)).setNumber(2);
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].returnVariable(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(0)).setNumber(2);
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}{runtimeScene.getGame().getVariables().get("time_limit").setNumber(30);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10904076);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 10;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("level_bcd"), gdjs.levelsCode.GDlevel_95bcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bcp"), gdjs.levelsCode.GDlevel_95bcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bd"), gdjs.levelsCode.GDlevel_95bdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bp"), gdjs.levelsCode.GDlevel_95bpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bsd"), gdjs.levelsCode.GDlevel_95bsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bsp"), gdjs.levelsCode.GDlevel_95bspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_btd"), gdjs.levelsCode.GDlevel_95btdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_btp"), gdjs.levelsCode.GDlevel_95btpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_cd"), gdjs.levelsCode.GDlevel_95cdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_cp"), gdjs.levelsCode.GDlevel_95cpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gcd"), gdjs.levelsCode.GDlevel_95gcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gcp"), gdjs.levelsCode.GDlevel_95gcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gd"), gdjs.levelsCode.GDlevel_95gdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gp"), gdjs.levelsCode.GDlevel_95gpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gsd"), gdjs.levelsCode.GDlevel_95gsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gsp"), gdjs.levelsCode.GDlevel_95gspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gtd"), gdjs.levelsCode.GDlevel_95gtdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gtp"), gdjs.levelsCode.GDlevel_95gtpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_map"), gdjs.levelsCode.GDlevel_95mapObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rcd"), gdjs.levelsCode.GDlevel_95rcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rcp"), gdjs.levelsCode.GDlevel_95rcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rd"), gdjs.levelsCode.GDlevel_95rdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rp"), gdjs.levelsCode.GDlevel_95rpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rsd"), gdjs.levelsCode.GDlevel_95rsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rsp"), gdjs.levelsCode.GDlevel_95rspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rtd"), gdjs.levelsCode.GDlevel_95rtdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rtp"), gdjs.levelsCode.GDlevel_95rtpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_sd"), gdjs.levelsCode.GDlevel_95sdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_sp"), gdjs.levelsCode.GDlevel_95spObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_star"), gdjs.levelsCode.GDlevel_95starObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_td"), gdjs.levelsCode.GDlevel_95tdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_tp"), gdjs.levelsCode.GDlevel_95tpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_wall"), gdjs.levelsCode.GDlevel_95wallObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.levelsCode.GDlevel_95rcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rcdObjects1[i].setTilemapJsonFile("levels\\level10.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gcdObjects1[i].setTilemapJsonFile("levels\\level10.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bcdObjects1[i].setTilemapJsonFile("levels\\level10.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rsdObjects1[i].setTilemapJsonFile("levels\\level10.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gsdObjects1[i].setTilemapJsonFile("levels\\level10.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bsdObjects1[i].setTilemapJsonFile("levels\\level10.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rtdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rtdObjects1[i].setTilemapJsonFile("levels\\level10.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gtdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gtdObjects1[i].setTilemapJsonFile("levels\\level10.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95btdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95btdObjects1[i].setTilemapJsonFile("levels\\level10.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rdObjects1[i].setTilemapJsonFile("levels\\level10.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gdObjects1[i].setTilemapJsonFile("levels\\level10.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bdObjects1[i].setTilemapJsonFile("levels\\level10.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rcpObjects1[i].setTilemapJsonFile("levels\\level10.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gcpObjects1[i].setTilemapJsonFile("levels\\level10.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bcpObjects1[i].setTilemapJsonFile("levels\\level10.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rspObjects1[i].setTilemapJsonFile("levels\\level10.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gspObjects1[i].setTilemapJsonFile("levels\\level10.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bspObjects1[i].setTilemapJsonFile("levels\\level10.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rtpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rtpObjects1[i].setTilemapJsonFile("levels\\level10.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gtpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gtpObjects1[i].setTilemapJsonFile("levels\\level10.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95btpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95btpObjects1[i].setTilemapJsonFile("levels\\level10.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rpObjects1[i].setTilemapJsonFile("levels\\level10.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gpObjects1[i].setTilemapJsonFile("levels\\level10.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bpObjects1[i].setTilemapJsonFile("levels\\level10.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95cpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95cpObjects1[i].setTilemapJsonFile("levels\\level10.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95spObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95spObjects1[i].setTilemapJsonFile("levels\\level10.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95tpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95tpObjects1[i].setTilemapJsonFile("levels\\level10.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95cdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95cdObjects1[i].setTilemapJsonFile("levels\\level10.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95sdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95sdObjects1[i].setTilemapJsonFile("levels\\level10.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95tdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95tdObjects1[i].setTilemapJsonFile("levels\\level10.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95starObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95starObjects1[i].setTilemapJsonFile("levels\\level10.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95wallObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95wallObjects1[i].setTilemapJsonFile("levels\\level10.json");
}
}{for(var i = 0, len = gdjs.levelsCode.GDlevel_95mapObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95mapObjects1[i].setTilemapJsonFile("levels\\level10.json");
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].setPosition(510,415);
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].returnVariable(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(1)).setNumber(3);
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].returnVariable(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(0)).setNumber(3);
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}{runtimeScene.getGame().getVariables().get("time_limit").setNumber(30);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10906612);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 11;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("level_bcd"), gdjs.levelsCode.GDlevel_95bcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bcp"), gdjs.levelsCode.GDlevel_95bcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bd"), gdjs.levelsCode.GDlevel_95bdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bp"), gdjs.levelsCode.GDlevel_95bpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bsd"), gdjs.levelsCode.GDlevel_95bsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bsp"), gdjs.levelsCode.GDlevel_95bspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_btd"), gdjs.levelsCode.GDlevel_95btdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_btp"), gdjs.levelsCode.GDlevel_95btpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_cd"), gdjs.levelsCode.GDlevel_95cdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_cp"), gdjs.levelsCode.GDlevel_95cpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gcd"), gdjs.levelsCode.GDlevel_95gcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gcp"), gdjs.levelsCode.GDlevel_95gcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gd"), gdjs.levelsCode.GDlevel_95gdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gp"), gdjs.levelsCode.GDlevel_95gpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gsd"), gdjs.levelsCode.GDlevel_95gsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gsp"), gdjs.levelsCode.GDlevel_95gspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gtd"), gdjs.levelsCode.GDlevel_95gtdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gtp"), gdjs.levelsCode.GDlevel_95gtpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_map"), gdjs.levelsCode.GDlevel_95mapObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rcd"), gdjs.levelsCode.GDlevel_95rcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rcp"), gdjs.levelsCode.GDlevel_95rcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rd"), gdjs.levelsCode.GDlevel_95rdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rp"), gdjs.levelsCode.GDlevel_95rpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rsd"), gdjs.levelsCode.GDlevel_95rsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rsp"), gdjs.levelsCode.GDlevel_95rspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rtd"), gdjs.levelsCode.GDlevel_95rtdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rtp"), gdjs.levelsCode.GDlevel_95rtpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_sd"), gdjs.levelsCode.GDlevel_95sdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_sp"), gdjs.levelsCode.GDlevel_95spObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_star"), gdjs.levelsCode.GDlevel_95starObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_td"), gdjs.levelsCode.GDlevel_95tdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_tp"), gdjs.levelsCode.GDlevel_95tpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_wall"), gdjs.levelsCode.GDlevel_95wallObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.levelsCode.GDlevel_95rcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rcdObjects1[i].setTilemapJsonFile("levels\\level11.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gcdObjects1[i].setTilemapJsonFile("levels\\level11.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bcdObjects1[i].setTilemapJsonFile("levels\\level11.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rsdObjects1[i].setTilemapJsonFile("levels\\level11.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gsdObjects1[i].setTilemapJsonFile("levels\\level11.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bsdObjects1[i].setTilemapJsonFile("levels\\level11.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rtdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rtdObjects1[i].setTilemapJsonFile("levels\\level11.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gtdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gtdObjects1[i].setTilemapJsonFile("levels\\level11.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95btdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95btdObjects1[i].setTilemapJsonFile("levels\\level11.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rdObjects1[i].setTilemapJsonFile("levels\\level11.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gdObjects1[i].setTilemapJsonFile("levels\\level11.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bdObjects1[i].setTilemapJsonFile("levels\\level11.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rcpObjects1[i].setTilemapJsonFile("levels\\level11.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gcpObjects1[i].setTilemapJsonFile("levels\\level11.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bcpObjects1[i].setTilemapJsonFile("levels\\level11.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rspObjects1[i].setTilemapJsonFile("levels\\level11.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gspObjects1[i].setTilemapJsonFile("levels\\level11.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bspObjects1[i].setTilemapJsonFile("levels\\level11.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rtpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rtpObjects1[i].setTilemapJsonFile("levels\\level11.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gtpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gtpObjects1[i].setTilemapJsonFile("levels\\level11.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95btpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95btpObjects1[i].setTilemapJsonFile("levels\\level11.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rpObjects1[i].setTilemapJsonFile("levels\\level11.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gpObjects1[i].setTilemapJsonFile("levels\\level11.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bpObjects1[i].setTilemapJsonFile("levels\\level11.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95cpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95cpObjects1[i].setTilemapJsonFile("levels\\level11.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95spObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95spObjects1[i].setTilemapJsonFile("levels\\level11.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95tpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95tpObjects1[i].setTilemapJsonFile("levels\\level11.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95cdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95cdObjects1[i].setTilemapJsonFile("levels\\level11.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95sdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95sdObjects1[i].setTilemapJsonFile("levels\\level11.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95tdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95tdObjects1[i].setTilemapJsonFile("levels\\level11.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95starObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95starObjects1[i].setTilemapJsonFile("levels\\level11.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95wallObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95wallObjects1[i].setTilemapJsonFile("levels\\level11.json");
}
}{for(var i = 0, len = gdjs.levelsCode.GDlevel_95mapObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95mapObjects1[i].setTilemapJsonFile("levels\\level11.json");
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].setPosition(726,469);
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].returnVariable(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(1)).setNumber(1);
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].returnVariable(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}{runtimeScene.getGame().getVariables().get("time_limit").setNumber(30);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10908716);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 12;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("level_bcd"), gdjs.levelsCode.GDlevel_95bcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bcp"), gdjs.levelsCode.GDlevel_95bcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bd"), gdjs.levelsCode.GDlevel_95bdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bp"), gdjs.levelsCode.GDlevel_95bpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bsd"), gdjs.levelsCode.GDlevel_95bsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bsp"), gdjs.levelsCode.GDlevel_95bspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_btd"), gdjs.levelsCode.GDlevel_95btdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_btp"), gdjs.levelsCode.GDlevel_95btpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_cd"), gdjs.levelsCode.GDlevel_95cdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_cp"), gdjs.levelsCode.GDlevel_95cpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gcd"), gdjs.levelsCode.GDlevel_95gcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gcp"), gdjs.levelsCode.GDlevel_95gcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gd"), gdjs.levelsCode.GDlevel_95gdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gp"), gdjs.levelsCode.GDlevel_95gpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gsd"), gdjs.levelsCode.GDlevel_95gsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gsp"), gdjs.levelsCode.GDlevel_95gspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gtd"), gdjs.levelsCode.GDlevel_95gtdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gtp"), gdjs.levelsCode.GDlevel_95gtpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_map"), gdjs.levelsCode.GDlevel_95mapObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rcd"), gdjs.levelsCode.GDlevel_95rcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rcp"), gdjs.levelsCode.GDlevel_95rcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rd"), gdjs.levelsCode.GDlevel_95rdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rp"), gdjs.levelsCode.GDlevel_95rpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rsd"), gdjs.levelsCode.GDlevel_95rsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rsp"), gdjs.levelsCode.GDlevel_95rspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rtd"), gdjs.levelsCode.GDlevel_95rtdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rtp"), gdjs.levelsCode.GDlevel_95rtpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_sd"), gdjs.levelsCode.GDlevel_95sdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_sp"), gdjs.levelsCode.GDlevel_95spObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_star"), gdjs.levelsCode.GDlevel_95starObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_td"), gdjs.levelsCode.GDlevel_95tdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_tp"), gdjs.levelsCode.GDlevel_95tpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_wall"), gdjs.levelsCode.GDlevel_95wallObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.levelsCode.GDlevel_95rcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rcdObjects1[i].setTilemapJsonFile("levels\\level12.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gcdObjects1[i].setTilemapJsonFile("levels\\level12.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bcdObjects1[i].setTilemapJsonFile("levels\\level12.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rsdObjects1[i].setTilemapJsonFile("levels\\level12.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gsdObjects1[i].setTilemapJsonFile("levels\\level12.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bsdObjects1[i].setTilemapJsonFile("levels\\level12.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rtdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rtdObjects1[i].setTilemapJsonFile("levels\\level12.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gtdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gtdObjects1[i].setTilemapJsonFile("levels\\level12.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95btdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95btdObjects1[i].setTilemapJsonFile("levels\\level12.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rdObjects1[i].setTilemapJsonFile("levels\\level12.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gdObjects1[i].setTilemapJsonFile("levels\\level12.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bdObjects1[i].setTilemapJsonFile("levels\\level12.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rcpObjects1[i].setTilemapJsonFile("levels\\level12.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gcpObjects1[i].setTilemapJsonFile("levels\\level12.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bcpObjects1[i].setTilemapJsonFile("levels\\level12.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rspObjects1[i].setTilemapJsonFile("levels\\level12.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gspObjects1[i].setTilemapJsonFile("levels\\level12.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bspObjects1[i].setTilemapJsonFile("levels\\level12.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rtpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rtpObjects1[i].setTilemapJsonFile("levels\\level12.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gtpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gtpObjects1[i].setTilemapJsonFile("levels\\level12.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95btpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95btpObjects1[i].setTilemapJsonFile("levels\\level12.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rpObjects1[i].setTilemapJsonFile("levels\\level12.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gpObjects1[i].setTilemapJsonFile("levels\\level12.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bpObjects1[i].setTilemapJsonFile("levels\\level12.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95cpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95cpObjects1[i].setTilemapJsonFile("levels\\level12.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95spObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95spObjects1[i].setTilemapJsonFile("levels\\level12.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95tpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95tpObjects1[i].setTilemapJsonFile("levels\\level12.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95cdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95cdObjects1[i].setTilemapJsonFile("levels\\level12.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95sdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95sdObjects1[i].setTilemapJsonFile("levels\\level12.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95tdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95tdObjects1[i].setTilemapJsonFile("levels\\level12.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95starObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95starObjects1[i].setTilemapJsonFile("levels\\level12.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95wallObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95wallObjects1[i].setTilemapJsonFile("levels\\level12.json");
}
}{for(var i = 0, len = gdjs.levelsCode.GDlevel_95mapObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95mapObjects1[i].setTilemapJsonFile("levels\\level12.json");
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].setPosition(345,415);
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].returnVariable(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(1)).setNumber(3);
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].returnVariable(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(0)).setNumber(3);
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}{runtimeScene.getGame().getVariables().get("time_limit").setNumber(30);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10910740);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 13;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("level_bcd"), gdjs.levelsCode.GDlevel_95bcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bcp"), gdjs.levelsCode.GDlevel_95bcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bd"), gdjs.levelsCode.GDlevel_95bdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bp"), gdjs.levelsCode.GDlevel_95bpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bsd"), gdjs.levelsCode.GDlevel_95bsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bsp"), gdjs.levelsCode.GDlevel_95bspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_btd"), gdjs.levelsCode.GDlevel_95btdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_btp"), gdjs.levelsCode.GDlevel_95btpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_cd"), gdjs.levelsCode.GDlevel_95cdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_cp"), gdjs.levelsCode.GDlevel_95cpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gcd"), gdjs.levelsCode.GDlevel_95gcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gcp"), gdjs.levelsCode.GDlevel_95gcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gd"), gdjs.levelsCode.GDlevel_95gdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gp"), gdjs.levelsCode.GDlevel_95gpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gsd"), gdjs.levelsCode.GDlevel_95gsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gsp"), gdjs.levelsCode.GDlevel_95gspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gtd"), gdjs.levelsCode.GDlevel_95gtdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gtp"), gdjs.levelsCode.GDlevel_95gtpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_map"), gdjs.levelsCode.GDlevel_95mapObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rcd"), gdjs.levelsCode.GDlevel_95rcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rcp"), gdjs.levelsCode.GDlevel_95rcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rd"), gdjs.levelsCode.GDlevel_95rdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rp"), gdjs.levelsCode.GDlevel_95rpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rsd"), gdjs.levelsCode.GDlevel_95rsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rsp"), gdjs.levelsCode.GDlevel_95rspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rtd"), gdjs.levelsCode.GDlevel_95rtdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rtp"), gdjs.levelsCode.GDlevel_95rtpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_sd"), gdjs.levelsCode.GDlevel_95sdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_sp"), gdjs.levelsCode.GDlevel_95spObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_star"), gdjs.levelsCode.GDlevel_95starObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_td"), gdjs.levelsCode.GDlevel_95tdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_tp"), gdjs.levelsCode.GDlevel_95tpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_wall"), gdjs.levelsCode.GDlevel_95wallObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.levelsCode.GDlevel_95rcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rcdObjects1[i].setTilemapJsonFile("levels\\level13.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gcdObjects1[i].setTilemapJsonFile("levels\\level13.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bcdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bcdObjects1[i].setTilemapJsonFile("levels\\level13.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rsdObjects1[i].setTilemapJsonFile("levels\\level13.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gsdObjects1[i].setTilemapJsonFile("levels\\level13.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bsdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bsdObjects1[i].setTilemapJsonFile("levels\\level13.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rtdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rtdObjects1[i].setTilemapJsonFile("levels\\level13.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gtdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gtdObjects1[i].setTilemapJsonFile("levels\\level13.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95btdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95btdObjects1[i].setTilemapJsonFile("levels\\level13.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rdObjects1[i].setTilemapJsonFile("levels\\level13.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gdObjects1[i].setTilemapJsonFile("levels\\level13.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bdObjects1[i].setTilemapJsonFile("levels\\level13.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rcpObjects1[i].setTilemapJsonFile("levels\\level13.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gcpObjects1[i].setTilemapJsonFile("levels\\level13.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bcpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bcpObjects1[i].setTilemapJsonFile("levels\\level13.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rspObjects1[i].setTilemapJsonFile("levels\\level13.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gspObjects1[i].setTilemapJsonFile("levels\\level13.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bspObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bspObjects1[i].setTilemapJsonFile("levels\\level13.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rtpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rtpObjects1[i].setTilemapJsonFile("levels\\level13.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gtpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gtpObjects1[i].setTilemapJsonFile("levels\\level13.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95btpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95btpObjects1[i].setTilemapJsonFile("levels\\level13.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95rpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95rpObjects1[i].setTilemapJsonFile("levels\\level13.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95gpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95gpObjects1[i].setTilemapJsonFile("levels\\level13.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95bpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95bpObjects1[i].setTilemapJsonFile("levels\\level13.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95cpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95cpObjects1[i].setTilemapJsonFile("levels\\level13.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95spObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95spObjects1[i].setTilemapJsonFile("levels\\level13.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95tpObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95tpObjects1[i].setTilemapJsonFile("levels\\level13.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95cdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95cdObjects1[i].setTilemapJsonFile("levels\\level13.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95sdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95sdObjects1[i].setTilemapJsonFile("levels\\level13.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95tdObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95tdObjects1[i].setTilemapJsonFile("levels\\level13.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95starObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95starObjects1[i].setTilemapJsonFile("levels\\level13.json");
}
for(var i = 0, len = gdjs.levelsCode.GDlevel_95wallObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95wallObjects1[i].setTilemapJsonFile("levels\\level13.json");
}
}{for(var i = 0, len = gdjs.levelsCode.GDlevel_95mapObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDlevel_95mapObjects1[i].setTilemapJsonFile("levels\\level13.json");
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].setPosition(510,207);
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].returnVariable(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(1)).setNumber(1);
}
}{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].returnVariable(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(0)).setNumber(3);
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}{runtimeScene.getGame().getVariables().get("time_limit").setNumber(30);
}}

}


{



}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDplayerObjects1.length;i<l;++i) {
    if ( gdjs.levelsCode.GDplayerObjects1[i].getVariableNumber(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDplayerObjects1[k] = gdjs.levelsCode.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.levelsCode.GDplayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDplayerObjects1.length;i<l;++i) {
    if ( gdjs.levelsCode.GDplayerObjects1[i].getVariableNumber(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(1)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDplayerObjects1[k] = gdjs.levelsCode.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.levelsCode.GDplayerObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.levelsCode.GDplayerObjects1 */
{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].setAnimationName("rc");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDplayerObjects1.length;i<l;++i) {
    if ( gdjs.levelsCode.GDplayerObjects1[i].getVariableNumber(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDplayerObjects1[k] = gdjs.levelsCode.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.levelsCode.GDplayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDplayerObjects1.length;i<l;++i) {
    if ( gdjs.levelsCode.GDplayerObjects1[i].getVariableNumber(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(1)) == 2 ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDplayerObjects1[k] = gdjs.levelsCode.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.levelsCode.GDplayerObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.levelsCode.GDplayerObjects1 */
{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].setAnimationName("gc");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDplayerObjects1.length;i<l;++i) {
    if ( gdjs.levelsCode.GDplayerObjects1[i].getVariableNumber(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDplayerObjects1[k] = gdjs.levelsCode.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.levelsCode.GDplayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDplayerObjects1.length;i<l;++i) {
    if ( gdjs.levelsCode.GDplayerObjects1[i].getVariableNumber(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(1)) == 3 ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDplayerObjects1[k] = gdjs.levelsCode.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.levelsCode.GDplayerObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.levelsCode.GDplayerObjects1 */
{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].setAnimationName("bc");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDplayerObjects1.length;i<l;++i) {
    if ( gdjs.levelsCode.GDplayerObjects1[i].getVariableNumber(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(0)) == 2 ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDplayerObjects1[k] = gdjs.levelsCode.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.levelsCode.GDplayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDplayerObjects1.length;i<l;++i) {
    if ( gdjs.levelsCode.GDplayerObjects1[i].getVariableNumber(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(1)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDplayerObjects1[k] = gdjs.levelsCode.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.levelsCode.GDplayerObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.levelsCode.GDplayerObjects1 */
{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].setAnimationName("rs");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDplayerObjects1.length;i<l;++i) {
    if ( gdjs.levelsCode.GDplayerObjects1[i].getVariableNumber(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(0)) == 2 ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDplayerObjects1[k] = gdjs.levelsCode.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.levelsCode.GDplayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDplayerObjects1.length;i<l;++i) {
    if ( gdjs.levelsCode.GDplayerObjects1[i].getVariableNumber(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(1)) == 2 ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDplayerObjects1[k] = gdjs.levelsCode.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.levelsCode.GDplayerObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.levelsCode.GDplayerObjects1 */
{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].setAnimationName("gs");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDplayerObjects1.length;i<l;++i) {
    if ( gdjs.levelsCode.GDplayerObjects1[i].getVariableNumber(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(0)) == 2 ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDplayerObjects1[k] = gdjs.levelsCode.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.levelsCode.GDplayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDplayerObjects1.length;i<l;++i) {
    if ( gdjs.levelsCode.GDplayerObjects1[i].getVariableNumber(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(1)) == 3 ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDplayerObjects1[k] = gdjs.levelsCode.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.levelsCode.GDplayerObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.levelsCode.GDplayerObjects1 */
{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].setAnimationName("bs");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDplayerObjects1.length;i<l;++i) {
    if ( gdjs.levelsCode.GDplayerObjects1[i].getVariableNumber(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(0)) == 3 ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDplayerObjects1[k] = gdjs.levelsCode.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.levelsCode.GDplayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDplayerObjects1.length;i<l;++i) {
    if ( gdjs.levelsCode.GDplayerObjects1[i].getVariableNumber(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(1)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDplayerObjects1[k] = gdjs.levelsCode.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.levelsCode.GDplayerObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.levelsCode.GDplayerObjects1 */
{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].setAnimationName("rt");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDplayerObjects1.length;i<l;++i) {
    if ( gdjs.levelsCode.GDplayerObjects1[i].getVariableNumber(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(0)) == 3 ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDplayerObjects1[k] = gdjs.levelsCode.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.levelsCode.GDplayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDplayerObjects1.length;i<l;++i) {
    if ( gdjs.levelsCode.GDplayerObjects1[i].getVariableNumber(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(1)) == 2 ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDplayerObjects1[k] = gdjs.levelsCode.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.levelsCode.GDplayerObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.levelsCode.GDplayerObjects1 */
{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].setAnimationName("gt");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDplayerObjects1.length;i<l;++i) {
    if ( gdjs.levelsCode.GDplayerObjects1[i].getVariableNumber(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(0)) == 3 ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDplayerObjects1[k] = gdjs.levelsCode.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.levelsCode.GDplayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDplayerObjects1.length;i<l;++i) {
    if ( gdjs.levelsCode.GDplayerObjects1[i].getVariableNumber(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(1)) == 3 ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDplayerObjects1[k] = gdjs.levelsCode.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.levelsCode.GDplayerObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.levelsCode.GDplayerObjects1 */
{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].setAnimationName("bt");
}
}}

}


{



}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("level_wall"), gdjs.levelsCode.GDlevel_95wallObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDplayerObjects1Objects, gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595wallObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.levelsCode.GDlevel_95wallObjects1 */
/* Reuse gdjs.levelsCode.GDplayerObjects1 */
{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].separateFromObjectsList(gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595wallObjects1Objects, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("level_star"), gdjs.levelsCode.GDlevel_95starObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDplayerObjects1Objects, gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595starObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(7230444);
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(1);
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "sound\\button.mp3", 100, false, 100, 1);
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("level_rcd"), gdjs.levelsCode.GDlevel_95rcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rd"), gdjs.levelsCode.GDlevel_95rdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rsd"), gdjs.levelsCode.GDlevel_95rsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rtd"), gdjs.levelsCode.GDlevel_95rtdObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDplayerObjects1.length;i<l;++i) {
    if ( !(gdjs.levelsCode.GDplayerObjects1[i].getVariableNumber(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(1)) == 1) ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDplayerObjects1[k] = gdjs.levelsCode.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.levelsCode.GDplayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDplayerObjects1Objects, gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595rcdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595rsdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595rtdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595rdObjects1Objects, false, runtimeScene, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.levelsCode.GDlevel_95rcdObjects1 */
/* Reuse gdjs.levelsCode.GDlevel_95rdObjects1 */
/* Reuse gdjs.levelsCode.GDlevel_95rsdObjects1 */
/* Reuse gdjs.levelsCode.GDlevel_95rtdObjects1 */
/* Reuse gdjs.levelsCode.GDplayerObjects1 */
{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].separateFromObjectsList(gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595rcdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595rsdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595rtdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595rdObjects1Objects, false);
}
}
{ //Subevents
gdjs.levelsCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("level_gcd"), gdjs.levelsCode.GDlevel_95gcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gd"), gdjs.levelsCode.GDlevel_95gdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gsd"), gdjs.levelsCode.GDlevel_95gsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gtd"), gdjs.levelsCode.GDlevel_95gtdObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDplayerObjects1.length;i<l;++i) {
    if ( !(gdjs.levelsCode.GDplayerObjects1[i].getVariableNumber(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(1)) == 2) ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDplayerObjects1[k] = gdjs.levelsCode.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.levelsCode.GDplayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDplayerObjects1Objects, gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595gcdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595gsdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595gtdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595gdObjects1Objects, false, runtimeScene, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.levelsCode.GDlevel_95gcdObjects1 */
/* Reuse gdjs.levelsCode.GDlevel_95gdObjects1 */
/* Reuse gdjs.levelsCode.GDlevel_95gsdObjects1 */
/* Reuse gdjs.levelsCode.GDlevel_95gtdObjects1 */
/* Reuse gdjs.levelsCode.GDplayerObjects1 */
{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].separateFromObjectsList(gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595gcdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595gsdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595gtdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595gdObjects1Objects, false);
}
}
{ //Subevents
gdjs.levelsCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("level_bcd"), gdjs.levelsCode.GDlevel_95bcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bd"), gdjs.levelsCode.GDlevel_95bdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bsd"), gdjs.levelsCode.GDlevel_95bsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_btd"), gdjs.levelsCode.GDlevel_95btdObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDplayerObjects1.length;i<l;++i) {
    if ( !(gdjs.levelsCode.GDplayerObjects1[i].getVariableNumber(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(1)) == 3) ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDplayerObjects1[k] = gdjs.levelsCode.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.levelsCode.GDplayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDplayerObjects1Objects, gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595bcdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595bsdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595btdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595bdObjects1Objects, false, runtimeScene, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.levelsCode.GDlevel_95bcdObjects1 */
/* Reuse gdjs.levelsCode.GDlevel_95bdObjects1 */
/* Reuse gdjs.levelsCode.GDlevel_95bsdObjects1 */
/* Reuse gdjs.levelsCode.GDlevel_95btdObjects1 */
/* Reuse gdjs.levelsCode.GDplayerObjects1 */
{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].separateFromObjectsList(gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595bcdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595bsdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595btdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595bdObjects1Objects, false);
}
}
{ //Subevents
gdjs.levelsCode.eventsList2(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("level_bcd"), gdjs.levelsCode.GDlevel_95bcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_cd"), gdjs.levelsCode.GDlevel_95cdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gcd"), gdjs.levelsCode.GDlevel_95gcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rcd"), gdjs.levelsCode.GDlevel_95rcdObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDplayerObjects1.length;i<l;++i) {
    if ( !(gdjs.levelsCode.GDplayerObjects1[i].getVariableNumber(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(0)) == 1) ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDplayerObjects1[k] = gdjs.levelsCode.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.levelsCode.GDplayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDplayerObjects1Objects, gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595rcdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595gcdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595bcdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595cdObjects1Objects, false, runtimeScene, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.levelsCode.GDlevel_95bcdObjects1 */
/* Reuse gdjs.levelsCode.GDlevel_95cdObjects1 */
/* Reuse gdjs.levelsCode.GDlevel_95gcdObjects1 */
/* Reuse gdjs.levelsCode.GDlevel_95rcdObjects1 */
/* Reuse gdjs.levelsCode.GDplayerObjects1 */
{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].separateFromObjectsList(gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595rcdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595gcdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595bcdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595cdObjects1Objects, false);
}
}
{ //Subevents
gdjs.levelsCode.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("level_bsd"), gdjs.levelsCode.GDlevel_95bsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gsd"), gdjs.levelsCode.GDlevel_95gsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rsd"), gdjs.levelsCode.GDlevel_95rsdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_sd"), gdjs.levelsCode.GDlevel_95sdObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDplayerObjects1.length;i<l;++i) {
    if ( !(gdjs.levelsCode.GDplayerObjects1[i].getVariableNumber(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(0)) == 2) ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDplayerObjects1[k] = gdjs.levelsCode.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.levelsCode.GDplayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDplayerObjects1Objects, gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595rsdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595gsdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595bsdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595sdObjects1Objects, false, runtimeScene, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.levelsCode.GDlevel_95bsdObjects1 */
/* Reuse gdjs.levelsCode.GDlevel_95gsdObjects1 */
/* Reuse gdjs.levelsCode.GDlevel_95rsdObjects1 */
/* Reuse gdjs.levelsCode.GDlevel_95sdObjects1 */
/* Reuse gdjs.levelsCode.GDplayerObjects1 */
{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].separateFromObjectsList(gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595rsdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595gsdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595bsdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595sdObjects1Objects, false);
}
}
{ //Subevents
gdjs.levelsCode.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("level_btd"), gdjs.levelsCode.GDlevel_95btdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gtd"), gdjs.levelsCode.GDlevel_95gtdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rtd"), gdjs.levelsCode.GDlevel_95rtdObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_td"), gdjs.levelsCode.GDlevel_95tdObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDplayerObjects1.length;i<l;++i) {
    if ( !(gdjs.levelsCode.GDplayerObjects1[i].getVariableNumber(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(0)) == 3) ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDplayerObjects1[k] = gdjs.levelsCode.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.levelsCode.GDplayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDplayerObjects1Objects, gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595rtdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595gtdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595btdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595tdObjects1Objects, false, runtimeScene, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.levelsCode.GDlevel_95btdObjects1 */
/* Reuse gdjs.levelsCode.GDlevel_95gtdObjects1 */
/* Reuse gdjs.levelsCode.GDlevel_95rtdObjects1 */
/* Reuse gdjs.levelsCode.GDlevel_95tdObjects1 */
/* Reuse gdjs.levelsCode.GDplayerObjects1 */
{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].separateFromObjectsList(gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595rtdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595gtdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595btdObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595tdObjects1Objects, false);
}
}
{ //Subevents
gdjs.levelsCode.eventsList5(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("level_rcp"), gdjs.levelsCode.GDlevel_95rcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rp"), gdjs.levelsCode.GDlevel_95rpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rsp"), gdjs.levelsCode.GDlevel_95rspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rtp"), gdjs.levelsCode.GDlevel_95rtpObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDplayerObjects1Objects, gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595rcpObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595rspObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595rtpObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595rpObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.levelsCode.GDplayerObjects1 */
{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].returnVariable(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(1)).setNumber(1);
}
}
{ //Subevents
gdjs.levelsCode.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("level_gcp"), gdjs.levelsCode.GDlevel_95gcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gp"), gdjs.levelsCode.GDlevel_95gpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gsp"), gdjs.levelsCode.GDlevel_95gspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gtp"), gdjs.levelsCode.GDlevel_95gtpObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDplayerObjects1Objects, gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595gcpObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595gspObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595gtpObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595gpObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.levelsCode.GDplayerObjects1 */
{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].returnVariable(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(1)).setNumber(2);
}
}
{ //Subevents
gdjs.levelsCode.eventsList7(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("level_bcp"), gdjs.levelsCode.GDlevel_95bcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bp"), gdjs.levelsCode.GDlevel_95bpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_bsp"), gdjs.levelsCode.GDlevel_95bspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_btp"), gdjs.levelsCode.GDlevel_95btpObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDplayerObjects1Objects, gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595bcpObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595bspObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595btpObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595bpObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.levelsCode.GDplayerObjects1 */
{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].returnVariable(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(1)).setNumber(3);
}
}
{ //Subevents
gdjs.levelsCode.eventsList8(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("level_bcp"), gdjs.levelsCode.GDlevel_95bcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_cp"), gdjs.levelsCode.GDlevel_95cpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gcp"), gdjs.levelsCode.GDlevel_95gcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rcp"), gdjs.levelsCode.GDlevel_95rcpObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDplayerObjects1Objects, gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595rcpObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595gcpObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595bcpObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595cpObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.levelsCode.GDplayerObjects1 */
{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].returnVariable(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}
{ //Subevents
gdjs.levelsCode.eventsList9(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("level_bsp"), gdjs.levelsCode.GDlevel_95bspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gsp"), gdjs.levelsCode.GDlevel_95gspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rsp"), gdjs.levelsCode.GDlevel_95rspObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_sp"), gdjs.levelsCode.GDlevel_95spObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDplayerObjects1Objects, gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595rspObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595gspObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595bspObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595spObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.levelsCode.GDplayerObjects1 */
{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].returnVariable(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(0)).setNumber(2);
}
}
{ //Subevents
gdjs.levelsCode.eventsList10(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("level_btp"), gdjs.levelsCode.GDlevel_95btpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_gtp"), gdjs.levelsCode.GDlevel_95gtpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_rtp"), gdjs.levelsCode.GDlevel_95rtpObjects1);
gdjs.copyArray(runtimeScene.getObjects("level_tp"), gdjs.levelsCode.GDlevel_95tpObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDplayerObjects1Objects, gdjs.levelsCode.mapOfGDgdjs_46levelsCode_46GDlevel_9595rtpObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595gtpObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595btpObjects1ObjectsGDgdjs_46levelsCode_46GDlevel_9595tpObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.levelsCode.GDplayerObjects1 */
{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].returnVariable(gdjs.levelsCode.GDplayerObjects1[i].getVariables().getFromIndex(0)).setNumber(3);
}
}
{ //Subevents
gdjs.levelsCode.eventsList11(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].addForce(0, -(200), 0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].addForce(0, 200, 0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].addForce(-(200), 0, 0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.levelsCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.levelsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDplayerObjects1[i].addForce(200, 0, 0);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) == 1;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "game_timer");
}
{ //Subevents
gdjs.levelsCode.eventsList21(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("next_level"), gdjs.levelsCode.GDnext_95levelObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDnext_95levelObjects1.length;i<l;++i) {
    if ( gdjs.levelsCode.GDnext_95levelObjects1[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDnext_95levelObjects1[k] = gdjs.levelsCode.GDnext_95levelObjects1[i];
        ++k;
    }
}
gdjs.levelsCode.GDnext_95levelObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17610956);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.levelsCode.GDtransitionObjects1);
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "sound\\button.mp3", 100, false, 100, 1);
}{runtimeScene.getGame().getVariables().getFromIndex(0).add(1);
}{for(var i = 0, len = gdjs.levelsCode.GDtransitionObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDtransitionObjects1[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.5, "Circular", "Forward", 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.levelsCode.eventsList22(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("try_again"), gdjs.levelsCode.GDtry_95againObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDtry_95againObjects1.length;i<l;++i) {
    if ( gdjs.levelsCode.GDtry_95againObjects1[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDtry_95againObjects1[k] = gdjs.levelsCode.GDtry_95againObjects1[i];
        ++k;
    }
}
gdjs.levelsCode.GDtry_95againObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10924676);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.levelsCode.GDtransitionObjects1);
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "sound\\button.mp3", 100, false, 100, 1);
}{for(var i = 0, len = gdjs.levelsCode.GDtransitionObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDtransitionObjects1[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.5, "Circular", "Forward", 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.levelsCode.eventsList23(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("quit_game"), gdjs.levelsCode.GDquit_95gameObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDquit_95gameObjects1.length;i<l;++i) {
    if ( gdjs.levelsCode.GDquit_95gameObjects1[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDquit_95gameObjects1[k] = gdjs.levelsCode.GDquit_95gameObjects1[i];
        ++k;
    }
}
gdjs.levelsCode.GDquit_95gameObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10925860);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.levelsCode.GDtransitionObjects1);
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "sound\\button.mp3", 100, false, 100, 1);
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(1);
}{for(var i = 0, len = gdjs.levelsCode.GDtransitionObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDtransitionObjects1[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.5, "Circular", "Forward", 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.levelsCode.eventsList24(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("moving_bg"), gdjs.levelsCode.GDmoving_95bgObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDmoving_95bgObjects1.length;i<l;++i) {
    if ( gdjs.levelsCode.GDmoving_95bgObjects1[i].getXOffset() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDmoving_95bgObjects1[k] = gdjs.levelsCode.GDmoving_95bgObjects1[i];
        ++k;
    }
}
gdjs.levelsCode.GDmoving_95bgObjects1.length = k;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(gdjs.randomInRange(-(2), 2));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("moving_bg"), gdjs.levelsCode.GDmoving_95bgObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDmoving_95bgObjects1.length;i<l;++i) {
    if ( gdjs.levelsCode.GDmoving_95bgObjects1[i].getYOffset() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDmoving_95bgObjects1[k] = gdjs.levelsCode.GDmoving_95bgObjects1[i];
        ++k;
    }
}
gdjs.levelsCode.GDmoving_95bgObjects1.length = k;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(gdjs.randomInRange(-(2), 2));
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("moving_bg"), gdjs.levelsCode.GDmoving_95bgObjects1);
{for(var i = 0, len = gdjs.levelsCode.GDmoving_95bgObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDmoving_95bgObjects1[i].setXOffset(gdjs.levelsCode.GDmoving_95bgObjects1[i].getXOffset() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))));
}
}{for(var i = 0, len = gdjs.levelsCode.GDmoving_95bgObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDmoving_95bgObjects1[i].setYOffset(gdjs.levelsCode.GDmoving_95bgObjects1[i].getYOffset() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("reset"), gdjs.levelsCode.GDresetObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDresetObjects1.length;i<l;++i) {
    if ( gdjs.levelsCode.GDresetObjects1[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDresetObjects1[k] = gdjs.levelsCode.GDresetObjects1[i];
        ++k;
    }
}
gdjs.levelsCode.GDresetObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16301948);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("game_time"), gdjs.levelsCode.GDgame_95timeObjects1);
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "sound\\button.mp3", 100, false, 100, 1);
}{for(var i = 0, len = gdjs.levelsCode.GDgame_95timeObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDgame_95timeObjects1[i].hide();
}
}
{ //Subevents
gdjs.levelsCode.eventsList26(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("exit"), gdjs.levelsCode.GDexitObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.levelsCode.GDexitObjects1.length;i<l;++i) {
    if ( gdjs.levelsCode.GDexitObjects1[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.levelsCode.GDexitObjects1[k] = gdjs.levelsCode.GDexitObjects1[i];
        ++k;
    }
}
gdjs.levelsCode.GDexitObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(19503796);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("game_time"), gdjs.levelsCode.GDgame_95timeObjects1);
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "sound\\button.mp3", 100, false, 100, 1);
}{for(var i = 0, len = gdjs.levelsCode.GDgame_95timeObjects1.length ;i < len;++i) {
    gdjs.levelsCode.GDgame_95timeObjects1[i].hide();
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(1);
}
{ //Subevents
gdjs.levelsCode.eventsList28(runtimeScene);} //End of subevents
}

}


};

gdjs.levelsCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.levelsCode.GDtransitionObjects1.length = 0;
gdjs.levelsCode.GDtransitionObjects2.length = 0;
gdjs.levelsCode.GDtransitionObjects3.length = 0;
gdjs.levelsCode.GDtransitionObjects4.length = 0;
gdjs.levelsCode.GDtransitionObjects5.length = 0;
gdjs.levelsCode.GDtransitionObjects6.length = 0;
gdjs.levelsCode.GDtransitionObjects7.length = 0;
gdjs.levelsCode.GDblackscreenObjects1.length = 0;
gdjs.levelsCode.GDblackscreenObjects2.length = 0;
gdjs.levelsCode.GDblackscreenObjects3.length = 0;
gdjs.levelsCode.GDblackscreenObjects4.length = 0;
gdjs.levelsCode.GDblackscreenObjects5.length = 0;
gdjs.levelsCode.GDblackscreenObjects6.length = 0;
gdjs.levelsCode.GDblackscreenObjects7.length = 0;
gdjs.levelsCode.GDtitle_95bgObjects1.length = 0;
gdjs.levelsCode.GDtitle_95bgObjects2.length = 0;
gdjs.levelsCode.GDtitle_95bgObjects3.length = 0;
gdjs.levelsCode.GDtitle_95bgObjects4.length = 0;
gdjs.levelsCode.GDtitle_95bgObjects5.length = 0;
gdjs.levelsCode.GDtitle_95bgObjects6.length = 0;
gdjs.levelsCode.GDtitle_95bgObjects7.length = 0;
gdjs.levelsCode.GDtitle_95fgObjects1.length = 0;
gdjs.levelsCode.GDtitle_95fgObjects2.length = 0;
gdjs.levelsCode.GDtitle_95fgObjects3.length = 0;
gdjs.levelsCode.GDtitle_95fgObjects4.length = 0;
gdjs.levelsCode.GDtitle_95fgObjects5.length = 0;
gdjs.levelsCode.GDtitle_95fgObjects6.length = 0;
gdjs.levelsCode.GDtitle_95fgObjects7.length = 0;
gdjs.levelsCode.GDred_95buttonObjects1.length = 0;
gdjs.levelsCode.GDred_95buttonObjects2.length = 0;
gdjs.levelsCode.GDred_95buttonObjects3.length = 0;
gdjs.levelsCode.GDred_95buttonObjects4.length = 0;
gdjs.levelsCode.GDred_95buttonObjects5.length = 0;
gdjs.levelsCode.GDred_95buttonObjects6.length = 0;
gdjs.levelsCode.GDred_95buttonObjects7.length = 0;
gdjs.levelsCode.GDgreen_95buttonObjects1.length = 0;
gdjs.levelsCode.GDgreen_95buttonObjects2.length = 0;
gdjs.levelsCode.GDgreen_95buttonObjects3.length = 0;
gdjs.levelsCode.GDgreen_95buttonObjects4.length = 0;
gdjs.levelsCode.GDgreen_95buttonObjects5.length = 0;
gdjs.levelsCode.GDgreen_95buttonObjects6.length = 0;
gdjs.levelsCode.GDgreen_95buttonObjects7.length = 0;
gdjs.levelsCode.GDmoving_95bgObjects1.length = 0;
gdjs.levelsCode.GDmoving_95bgObjects2.length = 0;
gdjs.levelsCode.GDmoving_95bgObjects3.length = 0;
gdjs.levelsCode.GDmoving_95bgObjects4.length = 0;
gdjs.levelsCode.GDmoving_95bgObjects5.length = 0;
gdjs.levelsCode.GDmoving_95bgObjects6.length = 0;
gdjs.levelsCode.GDmoving_95bgObjects7.length = 0;
gdjs.levelsCode.GDplayerObjects1.length = 0;
gdjs.levelsCode.GDplayerObjects2.length = 0;
gdjs.levelsCode.GDplayerObjects3.length = 0;
gdjs.levelsCode.GDplayerObjects4.length = 0;
gdjs.levelsCode.GDplayerObjects5.length = 0;
gdjs.levelsCode.GDplayerObjects6.length = 0;
gdjs.levelsCode.GDplayerObjects7.length = 0;
gdjs.levelsCode.GDnext_95levelObjects1.length = 0;
gdjs.levelsCode.GDnext_95levelObjects2.length = 0;
gdjs.levelsCode.GDnext_95levelObjects3.length = 0;
gdjs.levelsCode.GDnext_95levelObjects4.length = 0;
gdjs.levelsCode.GDnext_95levelObjects5.length = 0;
gdjs.levelsCode.GDnext_95levelObjects6.length = 0;
gdjs.levelsCode.GDnext_95levelObjects7.length = 0;
gdjs.levelsCode.GDresetObjects1.length = 0;
gdjs.levelsCode.GDresetObjects2.length = 0;
gdjs.levelsCode.GDresetObjects3.length = 0;
gdjs.levelsCode.GDresetObjects4.length = 0;
gdjs.levelsCode.GDresetObjects5.length = 0;
gdjs.levelsCode.GDresetObjects6.length = 0;
gdjs.levelsCode.GDresetObjects7.length = 0;
gdjs.levelsCode.GDsoundObjects1.length = 0;
gdjs.levelsCode.GDsoundObjects2.length = 0;
gdjs.levelsCode.GDsoundObjects3.length = 0;
gdjs.levelsCode.GDsoundObjects4.length = 0;
gdjs.levelsCode.GDsoundObjects5.length = 0;
gdjs.levelsCode.GDsoundObjects6.length = 0;
gdjs.levelsCode.GDsoundObjects7.length = 0;
gdjs.levelsCode.GDexitObjects1.length = 0;
gdjs.levelsCode.GDexitObjects2.length = 0;
gdjs.levelsCode.GDexitObjects3.length = 0;
gdjs.levelsCode.GDexitObjects4.length = 0;
gdjs.levelsCode.GDexitObjects5.length = 0;
gdjs.levelsCode.GDexitObjects6.length = 0;
gdjs.levelsCode.GDexitObjects7.length = 0;
gdjs.levelsCode.GDtry_95againObjects1.length = 0;
gdjs.levelsCode.GDtry_95againObjects2.length = 0;
gdjs.levelsCode.GDtry_95againObjects3.length = 0;
gdjs.levelsCode.GDtry_95againObjects4.length = 0;
gdjs.levelsCode.GDtry_95againObjects5.length = 0;
gdjs.levelsCode.GDtry_95againObjects6.length = 0;
gdjs.levelsCode.GDtry_95againObjects7.length = 0;
gdjs.levelsCode.GDquit_95gameObjects1.length = 0;
gdjs.levelsCode.GDquit_95gameObjects2.length = 0;
gdjs.levelsCode.GDquit_95gameObjects3.length = 0;
gdjs.levelsCode.GDquit_95gameObjects4.length = 0;
gdjs.levelsCode.GDquit_95gameObjects5.length = 0;
gdjs.levelsCode.GDquit_95gameObjects6.length = 0;
gdjs.levelsCode.GDquit_95gameObjects7.length = 0;
gdjs.levelsCode.GDlevel_95completeObjects1.length = 0;
gdjs.levelsCode.GDlevel_95completeObjects2.length = 0;
gdjs.levelsCode.GDlevel_95completeObjects3.length = 0;
gdjs.levelsCode.GDlevel_95completeObjects4.length = 0;
gdjs.levelsCode.GDlevel_95completeObjects5.length = 0;
gdjs.levelsCode.GDlevel_95completeObjects6.length = 0;
gdjs.levelsCode.GDlevel_95completeObjects7.length = 0;
gdjs.levelsCode.GDtime_95outObjects1.length = 0;
gdjs.levelsCode.GDtime_95outObjects2.length = 0;
gdjs.levelsCode.GDtime_95outObjects3.length = 0;
gdjs.levelsCode.GDtime_95outObjects4.length = 0;
gdjs.levelsCode.GDtime_95outObjects5.length = 0;
gdjs.levelsCode.GDtime_95outObjects6.length = 0;
gdjs.levelsCode.GDtime_95outObjects7.length = 0;
gdjs.levelsCode.GDplayer_95total_95scoreObjects1.length = 0;
gdjs.levelsCode.GDplayer_95total_95scoreObjects2.length = 0;
gdjs.levelsCode.GDplayer_95total_95scoreObjects3.length = 0;
gdjs.levelsCode.GDplayer_95total_95scoreObjects4.length = 0;
gdjs.levelsCode.GDplayer_95total_95scoreObjects5.length = 0;
gdjs.levelsCode.GDplayer_95total_95scoreObjects6.length = 0;
gdjs.levelsCode.GDplayer_95total_95scoreObjects7.length = 0;
gdjs.levelsCode.GDgame_95timeObjects1.length = 0;
gdjs.levelsCode.GDgame_95timeObjects2.length = 0;
gdjs.levelsCode.GDgame_95timeObjects3.length = 0;
gdjs.levelsCode.GDgame_95timeObjects4.length = 0;
gdjs.levelsCode.GDgame_95timeObjects5.length = 0;
gdjs.levelsCode.GDgame_95timeObjects6.length = 0;
gdjs.levelsCode.GDgame_95timeObjects7.length = 0;
gdjs.levelsCode.GDcontrolsObjects1.length = 0;
gdjs.levelsCode.GDcontrolsObjects2.length = 0;
gdjs.levelsCode.GDcontrolsObjects3.length = 0;
gdjs.levelsCode.GDcontrolsObjects4.length = 0;
gdjs.levelsCode.GDcontrolsObjects5.length = 0;
gdjs.levelsCode.GDcontrolsObjects6.length = 0;
gdjs.levelsCode.GDcontrolsObjects7.length = 0;
gdjs.levelsCode.GDdebugtextObjects1.length = 0;
gdjs.levelsCode.GDdebugtextObjects2.length = 0;
gdjs.levelsCode.GDdebugtextObjects3.length = 0;
gdjs.levelsCode.GDdebugtextObjects4.length = 0;
gdjs.levelsCode.GDdebugtextObjects5.length = 0;
gdjs.levelsCode.GDdebugtextObjects6.length = 0;
gdjs.levelsCode.GDdebugtextObjects7.length = 0;
gdjs.levelsCode.GDdebugtext_95xObjects1.length = 0;
gdjs.levelsCode.GDdebugtext_95xObjects2.length = 0;
gdjs.levelsCode.GDdebugtext_95xObjects3.length = 0;
gdjs.levelsCode.GDdebugtext_95xObjects4.length = 0;
gdjs.levelsCode.GDdebugtext_95xObjects5.length = 0;
gdjs.levelsCode.GDdebugtext_95xObjects6.length = 0;
gdjs.levelsCode.GDdebugtext_95xObjects7.length = 0;
gdjs.levelsCode.GDdebugtext_95yObjects1.length = 0;
gdjs.levelsCode.GDdebugtext_95yObjects2.length = 0;
gdjs.levelsCode.GDdebugtext_95yObjects3.length = 0;
gdjs.levelsCode.GDdebugtext_95yObjects4.length = 0;
gdjs.levelsCode.GDdebugtext_95yObjects5.length = 0;
gdjs.levelsCode.GDdebugtext_95yObjects6.length = 0;
gdjs.levelsCode.GDdebugtext_95yObjects7.length = 0;
gdjs.levelsCode.GDRoundSliderObjects1.length = 0;
gdjs.levelsCode.GDRoundSliderObjects2.length = 0;
gdjs.levelsCode.GDRoundSliderObjects3.length = 0;
gdjs.levelsCode.GDRoundSliderObjects4.length = 0;
gdjs.levelsCode.GDRoundSliderObjects5.length = 0;
gdjs.levelsCode.GDRoundSliderObjects6.length = 0;
gdjs.levelsCode.GDRoundSliderObjects7.length = 0;
gdjs.levelsCode.GDRoundSlider2Objects1.length = 0;
gdjs.levelsCode.GDRoundSlider2Objects2.length = 0;
gdjs.levelsCode.GDRoundSlider2Objects3.length = 0;
gdjs.levelsCode.GDRoundSlider2Objects4.length = 0;
gdjs.levelsCode.GDRoundSlider2Objects5.length = 0;
gdjs.levelsCode.GDRoundSlider2Objects6.length = 0;
gdjs.levelsCode.GDRoundSlider2Objects7.length = 0;
gdjs.levelsCode.GDRoundSlider3Objects1.length = 0;
gdjs.levelsCode.GDRoundSlider3Objects2.length = 0;
gdjs.levelsCode.GDRoundSlider3Objects3.length = 0;
gdjs.levelsCode.GDRoundSlider3Objects4.length = 0;
gdjs.levelsCode.GDRoundSlider3Objects5.length = 0;
gdjs.levelsCode.GDRoundSlider3Objects6.length = 0;
gdjs.levelsCode.GDRoundSlider3Objects7.length = 0;
gdjs.levelsCode.GDlevel_95mapObjects1.length = 0;
gdjs.levelsCode.GDlevel_95mapObjects2.length = 0;
gdjs.levelsCode.GDlevel_95mapObjects3.length = 0;
gdjs.levelsCode.GDlevel_95mapObjects4.length = 0;
gdjs.levelsCode.GDlevel_95mapObjects5.length = 0;
gdjs.levelsCode.GDlevel_95mapObjects6.length = 0;
gdjs.levelsCode.GDlevel_95mapObjects7.length = 0;
gdjs.levelsCode.GDlevel_95wallObjects1.length = 0;
gdjs.levelsCode.GDlevel_95wallObjects2.length = 0;
gdjs.levelsCode.GDlevel_95wallObjects3.length = 0;
gdjs.levelsCode.GDlevel_95wallObjects4.length = 0;
gdjs.levelsCode.GDlevel_95wallObjects5.length = 0;
gdjs.levelsCode.GDlevel_95wallObjects6.length = 0;
gdjs.levelsCode.GDlevel_95wallObjects7.length = 0;
gdjs.levelsCode.GDlevel_95rcdObjects1.length = 0;
gdjs.levelsCode.GDlevel_95rcdObjects2.length = 0;
gdjs.levelsCode.GDlevel_95rcdObjects3.length = 0;
gdjs.levelsCode.GDlevel_95rcdObjects4.length = 0;
gdjs.levelsCode.GDlevel_95rcdObjects5.length = 0;
gdjs.levelsCode.GDlevel_95rcdObjects6.length = 0;
gdjs.levelsCode.GDlevel_95rcdObjects7.length = 0;
gdjs.levelsCode.GDlevel_95gcdObjects1.length = 0;
gdjs.levelsCode.GDlevel_95gcdObjects2.length = 0;
gdjs.levelsCode.GDlevel_95gcdObjects3.length = 0;
gdjs.levelsCode.GDlevel_95gcdObjects4.length = 0;
gdjs.levelsCode.GDlevel_95gcdObjects5.length = 0;
gdjs.levelsCode.GDlevel_95gcdObjects6.length = 0;
gdjs.levelsCode.GDlevel_95gcdObjects7.length = 0;
gdjs.levelsCode.GDlevel_95bcdObjects1.length = 0;
gdjs.levelsCode.GDlevel_95bcdObjects2.length = 0;
gdjs.levelsCode.GDlevel_95bcdObjects3.length = 0;
gdjs.levelsCode.GDlevel_95bcdObjects4.length = 0;
gdjs.levelsCode.GDlevel_95bcdObjects5.length = 0;
gdjs.levelsCode.GDlevel_95bcdObjects6.length = 0;
gdjs.levelsCode.GDlevel_95bcdObjects7.length = 0;
gdjs.levelsCode.GDlevel_95rsdObjects1.length = 0;
gdjs.levelsCode.GDlevel_95rsdObjects2.length = 0;
gdjs.levelsCode.GDlevel_95rsdObjects3.length = 0;
gdjs.levelsCode.GDlevel_95rsdObjects4.length = 0;
gdjs.levelsCode.GDlevel_95rsdObjects5.length = 0;
gdjs.levelsCode.GDlevel_95rsdObjects6.length = 0;
gdjs.levelsCode.GDlevel_95rsdObjects7.length = 0;
gdjs.levelsCode.GDlevel_95gsdObjects1.length = 0;
gdjs.levelsCode.GDlevel_95gsdObjects2.length = 0;
gdjs.levelsCode.GDlevel_95gsdObjects3.length = 0;
gdjs.levelsCode.GDlevel_95gsdObjects4.length = 0;
gdjs.levelsCode.GDlevel_95gsdObjects5.length = 0;
gdjs.levelsCode.GDlevel_95gsdObjects6.length = 0;
gdjs.levelsCode.GDlevel_95gsdObjects7.length = 0;
gdjs.levelsCode.GDlevel_95bsdObjects1.length = 0;
gdjs.levelsCode.GDlevel_95bsdObjects2.length = 0;
gdjs.levelsCode.GDlevel_95bsdObjects3.length = 0;
gdjs.levelsCode.GDlevel_95bsdObjects4.length = 0;
gdjs.levelsCode.GDlevel_95bsdObjects5.length = 0;
gdjs.levelsCode.GDlevel_95bsdObjects6.length = 0;
gdjs.levelsCode.GDlevel_95bsdObjects7.length = 0;
gdjs.levelsCode.GDlevel_95rtdObjects1.length = 0;
gdjs.levelsCode.GDlevel_95rtdObjects2.length = 0;
gdjs.levelsCode.GDlevel_95rtdObjects3.length = 0;
gdjs.levelsCode.GDlevel_95rtdObjects4.length = 0;
gdjs.levelsCode.GDlevel_95rtdObjects5.length = 0;
gdjs.levelsCode.GDlevel_95rtdObjects6.length = 0;
gdjs.levelsCode.GDlevel_95rtdObjects7.length = 0;
gdjs.levelsCode.GDlevel_95gtdObjects1.length = 0;
gdjs.levelsCode.GDlevel_95gtdObjects2.length = 0;
gdjs.levelsCode.GDlevel_95gtdObjects3.length = 0;
gdjs.levelsCode.GDlevel_95gtdObjects4.length = 0;
gdjs.levelsCode.GDlevel_95gtdObjects5.length = 0;
gdjs.levelsCode.GDlevel_95gtdObjects6.length = 0;
gdjs.levelsCode.GDlevel_95gtdObjects7.length = 0;
gdjs.levelsCode.GDlevel_95btdObjects1.length = 0;
gdjs.levelsCode.GDlevel_95btdObjects2.length = 0;
gdjs.levelsCode.GDlevel_95btdObjects3.length = 0;
gdjs.levelsCode.GDlevel_95btdObjects4.length = 0;
gdjs.levelsCode.GDlevel_95btdObjects5.length = 0;
gdjs.levelsCode.GDlevel_95btdObjects6.length = 0;
gdjs.levelsCode.GDlevel_95btdObjects7.length = 0;
gdjs.levelsCode.GDlevel_95rdObjects1.length = 0;
gdjs.levelsCode.GDlevel_95rdObjects2.length = 0;
gdjs.levelsCode.GDlevel_95rdObjects3.length = 0;
gdjs.levelsCode.GDlevel_95rdObjects4.length = 0;
gdjs.levelsCode.GDlevel_95rdObjects5.length = 0;
gdjs.levelsCode.GDlevel_95rdObjects6.length = 0;
gdjs.levelsCode.GDlevel_95rdObjects7.length = 0;
gdjs.levelsCode.GDlevel_95gdObjects1.length = 0;
gdjs.levelsCode.GDlevel_95gdObjects2.length = 0;
gdjs.levelsCode.GDlevel_95gdObjects3.length = 0;
gdjs.levelsCode.GDlevel_95gdObjects4.length = 0;
gdjs.levelsCode.GDlevel_95gdObjects5.length = 0;
gdjs.levelsCode.GDlevel_95gdObjects6.length = 0;
gdjs.levelsCode.GDlevel_95gdObjects7.length = 0;
gdjs.levelsCode.GDlevel_95bdObjects1.length = 0;
gdjs.levelsCode.GDlevel_95bdObjects2.length = 0;
gdjs.levelsCode.GDlevel_95bdObjects3.length = 0;
gdjs.levelsCode.GDlevel_95bdObjects4.length = 0;
gdjs.levelsCode.GDlevel_95bdObjects5.length = 0;
gdjs.levelsCode.GDlevel_95bdObjects6.length = 0;
gdjs.levelsCode.GDlevel_95bdObjects7.length = 0;
gdjs.levelsCode.GDlevel_95rcpObjects1.length = 0;
gdjs.levelsCode.GDlevel_95rcpObjects2.length = 0;
gdjs.levelsCode.GDlevel_95rcpObjects3.length = 0;
gdjs.levelsCode.GDlevel_95rcpObjects4.length = 0;
gdjs.levelsCode.GDlevel_95rcpObjects5.length = 0;
gdjs.levelsCode.GDlevel_95rcpObjects6.length = 0;
gdjs.levelsCode.GDlevel_95rcpObjects7.length = 0;
gdjs.levelsCode.GDlevel_95gcpObjects1.length = 0;
gdjs.levelsCode.GDlevel_95gcpObjects2.length = 0;
gdjs.levelsCode.GDlevel_95gcpObjects3.length = 0;
gdjs.levelsCode.GDlevel_95gcpObjects4.length = 0;
gdjs.levelsCode.GDlevel_95gcpObjects5.length = 0;
gdjs.levelsCode.GDlevel_95gcpObjects6.length = 0;
gdjs.levelsCode.GDlevel_95gcpObjects7.length = 0;
gdjs.levelsCode.GDlevel_95bcpObjects1.length = 0;
gdjs.levelsCode.GDlevel_95bcpObjects2.length = 0;
gdjs.levelsCode.GDlevel_95bcpObjects3.length = 0;
gdjs.levelsCode.GDlevel_95bcpObjects4.length = 0;
gdjs.levelsCode.GDlevel_95bcpObjects5.length = 0;
gdjs.levelsCode.GDlevel_95bcpObjects6.length = 0;
gdjs.levelsCode.GDlevel_95bcpObjects7.length = 0;
gdjs.levelsCode.GDlevel_95rspObjects1.length = 0;
gdjs.levelsCode.GDlevel_95rspObjects2.length = 0;
gdjs.levelsCode.GDlevel_95rspObjects3.length = 0;
gdjs.levelsCode.GDlevel_95rspObjects4.length = 0;
gdjs.levelsCode.GDlevel_95rspObjects5.length = 0;
gdjs.levelsCode.GDlevel_95rspObjects6.length = 0;
gdjs.levelsCode.GDlevel_95rspObjects7.length = 0;
gdjs.levelsCode.GDlevel_95gspObjects1.length = 0;
gdjs.levelsCode.GDlevel_95gspObjects2.length = 0;
gdjs.levelsCode.GDlevel_95gspObjects3.length = 0;
gdjs.levelsCode.GDlevel_95gspObjects4.length = 0;
gdjs.levelsCode.GDlevel_95gspObjects5.length = 0;
gdjs.levelsCode.GDlevel_95gspObjects6.length = 0;
gdjs.levelsCode.GDlevel_95gspObjects7.length = 0;
gdjs.levelsCode.GDlevel_95bspObjects1.length = 0;
gdjs.levelsCode.GDlevel_95bspObjects2.length = 0;
gdjs.levelsCode.GDlevel_95bspObjects3.length = 0;
gdjs.levelsCode.GDlevel_95bspObjects4.length = 0;
gdjs.levelsCode.GDlevel_95bspObjects5.length = 0;
gdjs.levelsCode.GDlevel_95bspObjects6.length = 0;
gdjs.levelsCode.GDlevel_95bspObjects7.length = 0;
gdjs.levelsCode.GDlevel_95rtpObjects1.length = 0;
gdjs.levelsCode.GDlevel_95rtpObjects2.length = 0;
gdjs.levelsCode.GDlevel_95rtpObjects3.length = 0;
gdjs.levelsCode.GDlevel_95rtpObjects4.length = 0;
gdjs.levelsCode.GDlevel_95rtpObjects5.length = 0;
gdjs.levelsCode.GDlevel_95rtpObjects6.length = 0;
gdjs.levelsCode.GDlevel_95rtpObjects7.length = 0;
gdjs.levelsCode.GDlevel_95gtpObjects1.length = 0;
gdjs.levelsCode.GDlevel_95gtpObjects2.length = 0;
gdjs.levelsCode.GDlevel_95gtpObjects3.length = 0;
gdjs.levelsCode.GDlevel_95gtpObjects4.length = 0;
gdjs.levelsCode.GDlevel_95gtpObjects5.length = 0;
gdjs.levelsCode.GDlevel_95gtpObjects6.length = 0;
gdjs.levelsCode.GDlevel_95gtpObjects7.length = 0;
gdjs.levelsCode.GDlevel_95btpObjects1.length = 0;
gdjs.levelsCode.GDlevel_95btpObjects2.length = 0;
gdjs.levelsCode.GDlevel_95btpObjects3.length = 0;
gdjs.levelsCode.GDlevel_95btpObjects4.length = 0;
gdjs.levelsCode.GDlevel_95btpObjects5.length = 0;
gdjs.levelsCode.GDlevel_95btpObjects6.length = 0;
gdjs.levelsCode.GDlevel_95btpObjects7.length = 0;
gdjs.levelsCode.GDlevel_95rpObjects1.length = 0;
gdjs.levelsCode.GDlevel_95rpObjects2.length = 0;
gdjs.levelsCode.GDlevel_95rpObjects3.length = 0;
gdjs.levelsCode.GDlevel_95rpObjects4.length = 0;
gdjs.levelsCode.GDlevel_95rpObjects5.length = 0;
gdjs.levelsCode.GDlevel_95rpObjects6.length = 0;
gdjs.levelsCode.GDlevel_95rpObjects7.length = 0;
gdjs.levelsCode.GDlevel_95gpObjects1.length = 0;
gdjs.levelsCode.GDlevel_95gpObjects2.length = 0;
gdjs.levelsCode.GDlevel_95gpObjects3.length = 0;
gdjs.levelsCode.GDlevel_95gpObjects4.length = 0;
gdjs.levelsCode.GDlevel_95gpObjects5.length = 0;
gdjs.levelsCode.GDlevel_95gpObjects6.length = 0;
gdjs.levelsCode.GDlevel_95gpObjects7.length = 0;
gdjs.levelsCode.GDlevel_95bpObjects1.length = 0;
gdjs.levelsCode.GDlevel_95bpObjects2.length = 0;
gdjs.levelsCode.GDlevel_95bpObjects3.length = 0;
gdjs.levelsCode.GDlevel_95bpObjects4.length = 0;
gdjs.levelsCode.GDlevel_95bpObjects5.length = 0;
gdjs.levelsCode.GDlevel_95bpObjects6.length = 0;
gdjs.levelsCode.GDlevel_95bpObjects7.length = 0;
gdjs.levelsCode.GDlevel_95cpObjects1.length = 0;
gdjs.levelsCode.GDlevel_95cpObjects2.length = 0;
gdjs.levelsCode.GDlevel_95cpObjects3.length = 0;
gdjs.levelsCode.GDlevel_95cpObjects4.length = 0;
gdjs.levelsCode.GDlevel_95cpObjects5.length = 0;
gdjs.levelsCode.GDlevel_95cpObjects6.length = 0;
gdjs.levelsCode.GDlevel_95cpObjects7.length = 0;
gdjs.levelsCode.GDlevel_95spObjects1.length = 0;
gdjs.levelsCode.GDlevel_95spObjects2.length = 0;
gdjs.levelsCode.GDlevel_95spObjects3.length = 0;
gdjs.levelsCode.GDlevel_95spObjects4.length = 0;
gdjs.levelsCode.GDlevel_95spObjects5.length = 0;
gdjs.levelsCode.GDlevel_95spObjects6.length = 0;
gdjs.levelsCode.GDlevel_95spObjects7.length = 0;
gdjs.levelsCode.GDlevel_95tpObjects1.length = 0;
gdjs.levelsCode.GDlevel_95tpObjects2.length = 0;
gdjs.levelsCode.GDlevel_95tpObjects3.length = 0;
gdjs.levelsCode.GDlevel_95tpObjects4.length = 0;
gdjs.levelsCode.GDlevel_95tpObjects5.length = 0;
gdjs.levelsCode.GDlevel_95tpObjects6.length = 0;
gdjs.levelsCode.GDlevel_95tpObjects7.length = 0;
gdjs.levelsCode.GDlevel_95cdObjects1.length = 0;
gdjs.levelsCode.GDlevel_95cdObjects2.length = 0;
gdjs.levelsCode.GDlevel_95cdObjects3.length = 0;
gdjs.levelsCode.GDlevel_95cdObjects4.length = 0;
gdjs.levelsCode.GDlevel_95cdObjects5.length = 0;
gdjs.levelsCode.GDlevel_95cdObjects6.length = 0;
gdjs.levelsCode.GDlevel_95cdObjects7.length = 0;
gdjs.levelsCode.GDlevel_95sdObjects1.length = 0;
gdjs.levelsCode.GDlevel_95sdObjects2.length = 0;
gdjs.levelsCode.GDlevel_95sdObjects3.length = 0;
gdjs.levelsCode.GDlevel_95sdObjects4.length = 0;
gdjs.levelsCode.GDlevel_95sdObjects5.length = 0;
gdjs.levelsCode.GDlevel_95sdObjects6.length = 0;
gdjs.levelsCode.GDlevel_95sdObjects7.length = 0;
gdjs.levelsCode.GDlevel_95tdObjects1.length = 0;
gdjs.levelsCode.GDlevel_95tdObjects2.length = 0;
gdjs.levelsCode.GDlevel_95tdObjects3.length = 0;
gdjs.levelsCode.GDlevel_95tdObjects4.length = 0;
gdjs.levelsCode.GDlevel_95tdObjects5.length = 0;
gdjs.levelsCode.GDlevel_95tdObjects6.length = 0;
gdjs.levelsCode.GDlevel_95tdObjects7.length = 0;
gdjs.levelsCode.GDlevel_95starObjects1.length = 0;
gdjs.levelsCode.GDlevel_95starObjects2.length = 0;
gdjs.levelsCode.GDlevel_95starObjects3.length = 0;
gdjs.levelsCode.GDlevel_95starObjects4.length = 0;
gdjs.levelsCode.GDlevel_95starObjects5.length = 0;
gdjs.levelsCode.GDlevel_95starObjects6.length = 0;
gdjs.levelsCode.GDlevel_95starObjects7.length = 0;
gdjs.levelsCode.GDstart_95positionObjects1.length = 0;
gdjs.levelsCode.GDstart_95positionObjects2.length = 0;
gdjs.levelsCode.GDstart_95positionObjects3.length = 0;
gdjs.levelsCode.GDstart_95positionObjects4.length = 0;
gdjs.levelsCode.GDstart_95positionObjects5.length = 0;
gdjs.levelsCode.GDstart_95positionObjects6.length = 0;
gdjs.levelsCode.GDstart_95positionObjects7.length = 0;
gdjs.levelsCode.GDlevel_95bgObjects1.length = 0;
gdjs.levelsCode.GDlevel_95bgObjects2.length = 0;
gdjs.levelsCode.GDlevel_95bgObjects3.length = 0;
gdjs.levelsCode.GDlevel_95bgObjects4.length = 0;
gdjs.levelsCode.GDlevel_95bgObjects5.length = 0;
gdjs.levelsCode.GDlevel_95bgObjects6.length = 0;
gdjs.levelsCode.GDlevel_95bgObjects7.length = 0;
gdjs.levelsCode.GDwhite_95borderObjects1.length = 0;
gdjs.levelsCode.GDwhite_95borderObjects2.length = 0;
gdjs.levelsCode.GDwhite_95borderObjects3.length = 0;
gdjs.levelsCode.GDwhite_95borderObjects4.length = 0;
gdjs.levelsCode.GDwhite_95borderObjects5.length = 0;
gdjs.levelsCode.GDwhite_95borderObjects6.length = 0;
gdjs.levelsCode.GDwhite_95borderObjects7.length = 0;

gdjs.levelsCode.eventsList29(runtimeScene);

return;

}

gdjs['levelsCode'] = gdjs.levelsCode;

gdjs.guideCode = {};
gdjs.guideCode.GDtransitionObjects1= [];
gdjs.guideCode.GDtransitionObjects2= [];
gdjs.guideCode.GDtransitionObjects3= [];
gdjs.guideCode.GDblackscreenObjects1= [];
gdjs.guideCode.GDblackscreenObjects2= [];
gdjs.guideCode.GDblackscreenObjects3= [];
gdjs.guideCode.GDtitle_95bgObjects1= [];
gdjs.guideCode.GDtitle_95bgObjects2= [];
gdjs.guideCode.GDtitle_95bgObjects3= [];
gdjs.guideCode.GDtitle_95fgObjects1= [];
gdjs.guideCode.GDtitle_95fgObjects2= [];
gdjs.guideCode.GDtitle_95fgObjects3= [];
gdjs.guideCode.GDred_95buttonObjects1= [];
gdjs.guideCode.GDred_95buttonObjects2= [];
gdjs.guideCode.GDred_95buttonObjects3= [];
gdjs.guideCode.GDgreen_95buttonObjects1= [];
gdjs.guideCode.GDgreen_95buttonObjects2= [];
gdjs.guideCode.GDgreen_95buttonObjects3= [];
gdjs.guideCode.GDmoving_95bgObjects1= [];
gdjs.guideCode.GDmoving_95bgObjects2= [];
gdjs.guideCode.GDmoving_95bgObjects3= [];
gdjs.guideCode.GDguide_95textObjects1= [];
gdjs.guideCode.GDguide_95textObjects2= [];
gdjs.guideCode.GDguide_95textObjects3= [];
gdjs.guideCode.GDguide_95text2Objects1= [];
gdjs.guideCode.GDguide_95text2Objects2= [];
gdjs.guideCode.GDguide_95text2Objects3= [];
gdjs.guideCode.GDcontinueObjects1= [];
gdjs.guideCode.GDcontinueObjects2= [];
gdjs.guideCode.GDcontinueObjects3= [];
gdjs.guideCode.GDNewBBTextObjects1= [];
gdjs.guideCode.GDNewBBTextObjects2= [];
gdjs.guideCode.GDNewBBTextObjects3= [];


gdjs.guideCode.asyncCallback10869284 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("continue"), gdjs.guideCode.GDcontinueObjects3);
{for(var i = 0, len = gdjs.guideCode.GDcontinueObjects3.length ;i < len;++i) {
    gdjs.guideCode.GDcontinueObjects3[i].getBehavior("Tween").addObjectPositionYTween("slide_in", 750, "linear", 500, false);
}
}}
gdjs.guideCode.eventsList0 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.6), (runtimeScene) => (gdjs.guideCode.asyncCallback10869284(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.guideCode.asyncCallback10868156 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("guide_text"), gdjs.guideCode.GDguide_95textObjects2);
gdjs.copyArray(runtimeScene.getObjects("guide_text2"), gdjs.guideCode.GDguide_95text2Objects2);
{for(var i = 0, len = gdjs.guideCode.GDguide_95textObjects2.length ;i < len;++i) {
    gdjs.guideCode.GDguide_95textObjects2[i].getBehavior("Tween").addObjectPositionXTween("slide_in", 31, "linear", 750, false);
}
}{for(var i = 0, len = gdjs.guideCode.GDguide_95text2Objects2.length ;i < len;++i) {
    gdjs.guideCode.GDguide_95text2Objects2[i].getBehavior("Tween").addObjectPositionXTween("slide_in", 31, "linear", 750, false);
}
}
{ //Subevents
gdjs.guideCode.eventsList0(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.guideCode.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.guideCode.asyncCallback10868156(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.guideCode.asyncCallback10871740 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "levels", false);
}}
gdjs.guideCode.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.guideCode.asyncCallback10871740(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.guideCode.eventsList3 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.guideCode.GDtransitionObjects1);
{for(var i = 0, len = gdjs.guideCode.GDtransitionObjects1.length ;i < len;++i) {
    gdjs.guideCode.GDtransitionObjects1[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.5, "Flash", "Backward", 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.guideCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("continue"), gdjs.guideCode.GDcontinueObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.guideCode.GDcontinueObjects1.length;i<l;++i) {
    if ( gdjs.guideCode.GDcontinueObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.guideCode.GDcontinueObjects1[k] = gdjs.guideCode.GDcontinueObjects1[i];
        ++k;
    }
}
gdjs.guideCode.GDcontinueObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10870508);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.guideCode.GDtransitionObjects1);
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "sound\\button.mp3", 100, false, 100, 1);
}{for(var i = 0, len = gdjs.guideCode.GDtransitionObjects1.length ;i < len;++i) {
    gdjs.guideCode.GDtransitionObjects1[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.5, "Circular", "Forward", 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.guideCode.eventsList2(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("moving_bg"), gdjs.guideCode.GDmoving_95bgObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.guideCode.GDmoving_95bgObjects1.length;i<l;++i) {
    if ( gdjs.guideCode.GDmoving_95bgObjects1[i].getXOffset() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.guideCode.GDmoving_95bgObjects1[k] = gdjs.guideCode.GDmoving_95bgObjects1[i];
        ++k;
    }
}
gdjs.guideCode.GDmoving_95bgObjects1.length = k;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(gdjs.randomInRange(-(2), 2));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("moving_bg"), gdjs.guideCode.GDmoving_95bgObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.guideCode.GDmoving_95bgObjects1.length;i<l;++i) {
    if ( gdjs.guideCode.GDmoving_95bgObjects1[i].getYOffset() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.guideCode.GDmoving_95bgObjects1[k] = gdjs.guideCode.GDmoving_95bgObjects1[i];
        ++k;
    }
}
gdjs.guideCode.GDmoving_95bgObjects1.length = k;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(gdjs.randomInRange(-(2), 2));
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("moving_bg"), gdjs.guideCode.GDmoving_95bgObjects1);
{for(var i = 0, len = gdjs.guideCode.GDmoving_95bgObjects1.length ;i < len;++i) {
    gdjs.guideCode.GDmoving_95bgObjects1[i].setXOffset(gdjs.guideCode.GDmoving_95bgObjects1[i].getXOffset() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3))));
}
}{for(var i = 0, len = gdjs.guideCode.GDmoving_95bgObjects1.length ;i < len;++i) {
    gdjs.guideCode.GDmoving_95bgObjects1[i].setYOffset(gdjs.guideCode.GDmoving_95bgObjects1[i].getYOffset() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4))));
}
}}

}


};

gdjs.guideCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.guideCode.GDtransitionObjects1.length = 0;
gdjs.guideCode.GDtransitionObjects2.length = 0;
gdjs.guideCode.GDtransitionObjects3.length = 0;
gdjs.guideCode.GDblackscreenObjects1.length = 0;
gdjs.guideCode.GDblackscreenObjects2.length = 0;
gdjs.guideCode.GDblackscreenObjects3.length = 0;
gdjs.guideCode.GDtitle_95bgObjects1.length = 0;
gdjs.guideCode.GDtitle_95bgObjects2.length = 0;
gdjs.guideCode.GDtitle_95bgObjects3.length = 0;
gdjs.guideCode.GDtitle_95fgObjects1.length = 0;
gdjs.guideCode.GDtitle_95fgObjects2.length = 0;
gdjs.guideCode.GDtitle_95fgObjects3.length = 0;
gdjs.guideCode.GDred_95buttonObjects1.length = 0;
gdjs.guideCode.GDred_95buttonObjects2.length = 0;
gdjs.guideCode.GDred_95buttonObjects3.length = 0;
gdjs.guideCode.GDgreen_95buttonObjects1.length = 0;
gdjs.guideCode.GDgreen_95buttonObjects2.length = 0;
gdjs.guideCode.GDgreen_95buttonObjects3.length = 0;
gdjs.guideCode.GDmoving_95bgObjects1.length = 0;
gdjs.guideCode.GDmoving_95bgObjects2.length = 0;
gdjs.guideCode.GDmoving_95bgObjects3.length = 0;
gdjs.guideCode.GDguide_95textObjects1.length = 0;
gdjs.guideCode.GDguide_95textObjects2.length = 0;
gdjs.guideCode.GDguide_95textObjects3.length = 0;
gdjs.guideCode.GDguide_95text2Objects1.length = 0;
gdjs.guideCode.GDguide_95text2Objects2.length = 0;
gdjs.guideCode.GDguide_95text2Objects3.length = 0;
gdjs.guideCode.GDcontinueObjects1.length = 0;
gdjs.guideCode.GDcontinueObjects2.length = 0;
gdjs.guideCode.GDcontinueObjects3.length = 0;
gdjs.guideCode.GDNewBBTextObjects1.length = 0;
gdjs.guideCode.GDNewBBTextObjects2.length = 0;
gdjs.guideCode.GDNewBBTextObjects3.length = 0;

gdjs.guideCode.eventsList3(runtimeScene);

return;

}

gdjs['guideCode'] = gdjs.guideCode;
